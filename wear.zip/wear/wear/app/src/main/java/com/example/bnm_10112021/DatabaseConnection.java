package com.example.bnm_10112021;

import android.os.Bundle;
import android.os.StrictMode;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection extends AppCompatActivity {
    //Deklarierung einiger Variablen
    public Connection con;
    public Statement stm;
    public int anzahlRs = 0;
    String rückgabe;
    //Initialisierung von den Parametern für die getConnection-Methode
    String url = "url";
    String user = "user";
    String pass = "pass";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    //Methode zum Einfügen von Daten
    public void insert(String tabellenName, String spaltenNamen, String werte) {
        //try catch exception fängt SQL Fehlermeldungen
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            //Verbindung zur URL mit passendem Nutzernamen und Passwort wird erstellt
            con = DriverManager.getConnection(url, user, pass);
            //SQL Statement wird erstellt und ausgeführt
            stm = con.createStatement();
            String abfrage = "INSERT INTO " + tabellenName + " (" + spaltenNamen + ") VALUES " + werte;
            stm.execute(abfrage);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    //Methode zum Löschen von Daten
    public void delete(String spaltenName, String tabellenName, String wert) {
        //try catch exception fängt SQL Fehlermeldungen
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            //Verbindung zur URL mit passendem Nutzernamen und Passwort wird erstellt
            con = DriverManager.getConnection(url, user, pass);
            //SQL Statement wird erstellt und ausgeführt
            stm = con.createStatement();
            String abfrage = "DELETE FROM " + tabellenName + " WHERE " + spaltenName + " = " + wert;
            stm.execute(abfrage);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    //Methode zum Aktualisieren von Daten
    public void update(String spaltenName, String spaltenName2, String tabellenName, String identifikationWert, String neuerWert) {
        //try catch exception fängt SQL Fehlermeldungen
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            //Verbindung zur URL mit passendem Nutzernamen und Passwort wird erstellt
            con = DriverManager.getConnection(url, user, pass);
            //SQL Statement wird erstellt und ausgeführt
            stm = con.createStatement();
            String abfrage = "UPDATE " + tabellenName + " SET " + spaltenName + " = " + neuerWert + " WHERE " + spaltenName2 + " = " + identifikationWert;
            stm.execute(abfrage);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * Methode zum Abruf von max 10 Daten aus der Datenbank
     *
     * @param spaltenName     Text im SQL Statment zwischen dem Select- und From-Befehl
     * @param tabellenName    Text im SQL Statment zwischen dem From- und Where-Befehl
     * @param bedingung       Text im SQL Statement nach dem Where-Befehl
     * @param anzahlVariablen Anzahl an Variablen die man aus der DB kriegen will
     * @return rueckgabe-Array mit den Werten aus der DB
     **/
    public String[] select(String spaltenName, String tabellenName, String bedingung, String anzahlVariablen) {
        String[] rueckgabe = new String[0];
        //try catch exception fängt SQL Fehlermeldungen
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            //Verbindung zur URL mit passendem Nutzernamen und Passwort wird erstellt
            con = DriverManager.getConnection(url, user, pass);
            //SQL Statement wird erstellt
            stm = con.createStatement();
            String abfrage = "SELECT " + spaltenName + " FROM " + tabellenName + " WHERE " + bedingung;
            //Resultset-Objekt führt das SQL Statement durch
            ResultSet rs = stm.executeQuery(abfrage);
            //Resultset-Objekt zählt wie viele Zeilen es gibt und speichert die Anzahl in der int Variable anzahl
            rs.last();
            anzahlRs = rs.getRow();
            rs.beforeFirst();
            int anzahl = Integer.valueOf(anzahlVariablen);
            rueckgabe = new String[anzahl * anzahlRs];
            //Füllt den Array rueckgabe mit allen zurückgegebenen Werten aus dem ResultSet
            int n = 0;
            for (int k = 0; k < anzahlRs; k++) {
                rs.next();
                for (int i = 1; i <= anzahl; i++) {
                    rueckgabe[n] = rs.getString(i);
                    n++;
                }
            }
            //Schließt die Verbindung zur Datenbank
            rs.close();
            stm.close();
            //gibt den Array rueckgabe zuück
            return rueckgabe;
        } catch (SQLException throwables) {
            System.out.println("DB");
            throwables.printStackTrace();
        }
        return rueckgabe;
    }
}