package com.example.bnm_10112021;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefMessage;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.navigation.NavigationBarView;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.ExecutionException;

public class Scan extends AppCompatActivity {


    public static final String Error_Detected = "No NFC Tag Detected";
    public static final String Write_Success = "Text Written Successfully!";
    public static final String Write_Error = "Error during Writing, Try Again!";
    public static final String MIME_TEXT_PLAIN = "text/plain";
    //Erstellung des dbConnection-Objekts
    public DatabaseConnection dbConnector = new DatabaseConnection();
    NfcAdapter nfcAdapter;
    PendingIntent pendingIntent;
    Tag myTag;
    Context context;
    TextView nfc_contents;
    boolean scanActive;
    MainActivity main;

    BottomNavigationView bottomNavigationItemView;

    public static void setupForegroundDispatch(final Activity activity, NfcAdapter adapter) {
        final Intent intent = new Intent(activity.getApplicationContext(), activity.getClass());
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

        final PendingIntent pendingIntent = PendingIntent.getActivity(activity.getApplicationContext(), 0, intent, 0);

        IntentFilter[] filters = new IntentFilter[1];
        String[][] techList = new String[][]{};

        // Notice that this is the same filter as in our manifest.
        filters[0] = new IntentFilter();
        filters[0].addAction(NfcAdapter.ACTION_NDEF_DISCOVERED);
        filters[0].addCategory(Intent.CATEGORY_DEFAULT);
        try {
            filters[0].addDataType(MIME_TEXT_PLAIN);
        } catch (IntentFilter.MalformedMimeTypeException e) {
            throw new RuntimeException("Check your mime type.");
        }

        adapter.enableForegroundDispatch(activity, pendingIntent, filters, techList);
    }

    public static void stopForegroundDispatch(final Activity activity, NfcAdapter adapter) {
        adapter.disableForegroundDispatch(activity);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        main = new MainActivity();

        bottomNavigationItemView = findViewById(R.id.navigator);
        bottomNavigationItemView.setSelectedItemId(R.id.scan);

        /**TextView nutzer = (TextView) findViewById(R.id.nutzer);
        String[] rueckgabe = new String[0];
        System.out.println(main.aBenutzerID);
        try {
            rueckgabe = new DauertLange().execute("Benutzername","Benutzerdaten","BenutzerID = '" + main.aBenutzerID + "'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(rueckgabe[0]);
        nutzer.setText(rueckgabe[0]);**/

        nfc_contents = (TextView) findViewById(R.id.nfc_contents);
        context = this;
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        /**if(nfcAdapter == null){
         Toast.makeText(this, "This device does not support NFC", Toast.LENGTH_SHORT).show();
         finish();
         }**/

        scanActive = false;
        pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        tagDetected.addCategory(Intent.CATEGORY_DEFAULT);


        //DOKU, VERALTET!!!!
        bottomNavigationItemView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                switch (id) {
                    case R.id.settings:
                        scanActive = false;
                        startActivity(new Intent(getApplicationContext(), Settings.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.stats:
                        scanActive = false;
                        startActivity(new Intent(getApplicationContext(), Statistics.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.scan:
                        return true;
                    case R.id.wash:
                        scanActive = false;
                        startActivity(new Intent(getApplicationContext(), Wash.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.mycloset:
                        scanActive = false;
                        startActivity(new Intent(getApplicationContext(), MyCloset.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });

        //Button enableScan = (Button) findViewById(R.id.enableScan);
        /**enableScan.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View view) {
        scanActive = true;
        readFromIntent(getIntent());

        }
        });**/
    }

    private void readFromIntent(Intent intent) {
        String action = null;
        action = intent.getAction();
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)) {
            Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
            NdefMessage[] msgs = null;
            if (rawMsgs != null) {
                msgs = new NdefMessage[rawMsgs.length];
                for (int i = 0; i < rawMsgs.length; i++) {
                    msgs[i] = (NdefMessage) rawMsgs[i];
                }
            }
            buildTagViews(msgs);
        }


    }

    private void buildTagViews(NdefMessage[] msgs) {
        Context c = this;
        if (msgs == null || msgs.length == 0) return;

        String text = "";
        byte[] payload = msgs[0].getRecords()[0].getPayload();
        String textEncoding = ((payload[0] & 128) == 0) ? "UTF-8" : "UTF-16"; // Get the Text Encoding
        int languageCodeLength = payload[0] & 0063; // Get the Language Code, e.g. "en"

        try {
            // Get the Text
            text = new String(payload, languageCodeLength + 1, payload.length - languageCodeLength - 1, textEncoding);
        } catch (UnsupportedEncodingException e) {
            Log.e("UnsupportedEncoding", e.toString());
        }

        String chipID = text;

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(

                Scan.this, R.style.BottomSheetDialogTheme
        );
        View bottomSheetView = LayoutInflater.from(getApplicationContext())
                .inflate(
                        R.layout.layout_bottom_sheet,
                        null

                );
        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();

        //bottomSheetDialog.setContentView(R.layout.layout_bottom_sheet_loading);

        LinearLayout ll = bottomSheetView.findViewById(R.id.bottomSheetContainer);

        //Textfelder identifzieren
        TextView tvBezeichnung = ll.findViewById(R.id.tvBezeichnung);
        TextView tvMarke = ll.findViewById(R.id.tvMarke);
        TextView tvColor = ll.findViewById(R.id.tvColor);
        TextView tvSize = ll.findViewById(R.id.tvSize);
        TextView tvHerkunft = ll.findViewById(R.id.tvHerkunft);
        TextView tvDatum = ll.findViewById(R.id.datum);


        //Datenbankverbindung über AsyncTask mit Array als Rückgabe
        String[] farbe = new String[10];
        try {
            farbe = new DauertLange().execute("Kleidungstypen.Bezeichnung, Kleidungstypen.Marke, Kleidungstypen.Farbe, Kleidungstypen.Size, Kleidungstypen.Herkunft", "Kleidungstypen INNER JOIN Chips ON Kleidungstypen.Seriennummer = Chips.Seriennummer", "NFCID = '" + chipID + "'", "5").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
            bottomSheetDialog.dismiss();
        } catch (InterruptedException e) {
            e.printStackTrace();
            bottomSheetDialog.dismiss();
        }
        String[] rueckgabe2 = new String[0];
        try {
            rueckgabe2 = new DauertLange().execute("BenutzerID", "Chips", "NFCID = '" + chipID + "'","1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int bID = Integer.valueOf(rueckgabe2[0]);
        scanActive = false;

        //Inhalte der Textfelder mit Daten aus DB setzen
        tvBezeichnung.setText(farbe[0]);
        tvMarke.setText(farbe[1]);
        tvColor.setText(farbe[2]);
        tvSize.setText(farbe[3]);
        tvHerkunft.setText("Made in " + farbe[4]);
        if (bID == main.aBenutzerID){
            tvDatum.setText("Sie sind der Besitzer!");
        } else if (bID == 0){
            tvDatum.setText("Es gibt einen Besitzer.");
        } else {
            tvDatum.setText("Es ist leider schon verkauft.");
        }

        //RoundedImageView img = ll.findViewById(R.id.image111);
        //img.setImageURI(uri);


        bottomSheetView.findViewById(R.id.addToCloset).setOnClickListener(new View.OnClickListener() {
            @Override
            //wenn der add Now Button geklickt wird
            public void onClick(View view) {
                //Check ob schon in Besitz
                String[] rueckgabe = new String[1];
                try {
                    rueckgabe = new DauertLange().execute("BenutzerID", "Chips", "NFCID = '" + chipID + "'", "1").get();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //wenn noch kein Besitzer...
                if (rueckgabe[0].equals("0")) {
                    //Setzen des Kaufdatums
                    Date datum = Calendar.getInstance().getTime();
                    SimpleDateFormat dateformat = new SimpleDateFormat("dd/MM/yyyy");
                    String d = dateformat.format(datum);
                    dbConnector.update("Kaufdatum", "NFCID", "Chips", chipID, "'" + d + "'");
                    //Setzen der BenutzerID zum gescannten Chip
                    dbConnector.update("BenutzerID", "NFCID", "Chips", chipID, String.valueOf(main.aBenutzerID));
                    //Ausgabe
                    Toast.makeText(c, "Erfolgreich hionzugefügt!", Toast.LENGTH_LONG).show();
                } else if (rueckgabe[0].equals(String.valueOf(main.aBenutzerID))) {
                    Toast.makeText(c, "Dieses Kleidungsstück gehört dir schon!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(c, "Dieses Kleidungsstück ist bereits verkauft!", Toast.LENGTH_LONG).show();
                }

            }
        });
        //bottomSheetDialog.setContentView(bottomSheetView);
        //bottomSheetDialog.show();

    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        readFromIntent(intent);
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())) {
            myTag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        }
    }

    @Override
    public void onPause() {

        stopForegroundDispatch(this, nfcAdapter);
        super.onPause();
        System.out.println("pause");
        // nfcAdapter.disableReaderMode(this);
       // nfcAdapter.disableForegroundDispatch(this);
    }

    @Override
    public void onResume() {
        setupForegroundDispatch(this, nfcAdapter);
        super.onResume();

        System.out.println("resume");
        //nfcAdapter.enableReaderMode();
        //nfcAdapter.enableForegroundDispatch(this, pendingIntent, writingTagFilters, null);
    }

    //String: Parameter an doInBackground; Void: Parameter an publishProgress bzw. onProgressUpdate; String[]: Parameter von doInBackground an onPostExecute
    private class DauertLange extends AsyncTask<String, Void, String[]> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Vorher");
        }

        @Override
        protected String[] doInBackground(String... pStrings) {
            //publishProgress();
            String sN = pStrings[0];
            String tN = pStrings[1];
            String bd = pStrings[2];
            String z = pStrings[3];
            System.out.println(tN);

            String[] rueckgabe = dbConnector.select(sN, tN, bd, z);
            return rueckgabe;
        }

        /**
         * protected void onProgressUpdate(){
         * bottomSheetDialog.setContentView(R.layout.layout_bottom_sheet_loading);
         * <p>
         * }
         **/
        protected void onPostExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Nacher");
        }
    }


}


