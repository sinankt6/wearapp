package com.example.bnm_10112021;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.navigation.NavigationBarView;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;


public class MyCloset extends AppCompatActivity {

    public static final String Error_Detected = "No NFC Tag Detected";
    public static final String Write_Success = "Text Written Successfully!";
    public static final String Write_Error = "Error during Writing, Try Again!";

    //Initalisierung von Variablen
    ArrayList<String> sNummern = new ArrayList<>();
    ArrayList<String> bezeichnungen = new ArrayList<>();
    ArrayList<String> allNamen = new ArrayList<>();
    ArrayList<String> allNummern = new ArrayList<>();

    //Arrays mit der Bezeichnung und den Bildern zu den Kategorien
    String[] kategorien = {"T-Shirts", "Sweatshirts", "Kapuzenpullover", "Zip-Hoodie", "Hosen", "Jeanshosen", "Jacken", "Kleider", "Gesamte Kleidung"};
    int[] kIcons = {R.drawable.poloshirt, R.drawable.sweatshirt, R.drawable.hoodie, R.drawable.kapuzenjacke, R.drawable.hose, R.drawable.shorts, R.drawable.jacke, R.drawable.kleid, R.drawable.tshirt};

    /** false -> Kategorien und true -> Kleidungsstücke**/
    Boolean status = false;

    Button zurueck;
    int kategorie;

    int z = 0;

    MainActivity main;

    BottomNavigationView bottomNavigationItemView;
    //Objekt der Klasse DatabaseConnection wird erstellt
    DatabaseConnection dbConnector = new DatabaseConnection();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_closet);
        bottomNavigationItemView = findViewById(R.id.navigator);
        bottomNavigationItemView.setSelectedItemId(R.id.mycloset);

        main = new MainActivity();

        //DOKU, VERALTET!!!!

        //OnItemSelectedListener vom Bottom Navigation Menü
        bottomNavigationItemView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                switch (id) {
                    case R.id.settings:
                        startActivity(new Intent(getApplicationContext(), Settings.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.stats:
                        startActivity(new Intent(getApplicationContext(), Statistics.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.scan:
                        startActivity(new Intent(getApplicationContext(), Scan.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.wash:
                        startActivity(new Intent(getApplicationContext(), Wash.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.mycloset:
                        return true;
                }
                return false;
            }
        });



        GridView gridView = (GridView) findViewById(R.id.gridView);
        zurueck = (Button) findViewById(R.id.zurueck);
        CustomAdapter customAdapter = new CustomAdapter();

        //Namen und Seriennnumern der Kleidungsstücke werden aus der Datenbank abgerufen und im Array werte gespeichert


        //dem gridView wird der Adapter customAdapter zugewiesen
        gridView.setAdapter(customAdapter);

        //GridView OnItemClickListener
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //if-else-Verzweigung, je nachdem welche Seite aktiv ist (Kategorien oder genaue Kleidungsstücke)
                if (status) {
                    String[] rueckgabe = new String[0];
                    try {
                        rueckgabe = new DauertLange().execute("Bezeichnung, Marke, Farbe, Size, Herkunft", "Kleidungstypen", "Seriennummer = '" + sNummern.get(i) + "'", "5").get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    String[] rueckgabe2 = new String[0];
                    try {
                        rueckgabe2 = new DauertLange().execute("Kaufdatum", "Chips", "Seriennummer = '" + sNummern.get(i) + "'","1").get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    LocalDate datumHeute = LocalDate.now();
                    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate localDate = LocalDate.parse(rueckgabe2[0], dateTimeFormatter);
                    Duration diff = Duration.between(localDate.atStartOfDay(), datumHeute.atStartOfDay());
                    int tage = (int) diff.toDays();
                    String datumsZeile = rueckgabe2[0] + " // Tage seit Kauf: " + tage;
                    //Bottom Sheet wird aufgerufen und mit Werten aus der DB befüllt
                    extendSheet(rueckgabe[0], rueckgabe[1], rueckgabe[2], rueckgabe[3], rueckgabe[4], datumsZeile);
                } else if (!status) {
                    kategorie = i;
                    gridView.setAdapter(customAdapter);
                    z = 0;
                    status = true;


                }
            }
        });

        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                int element = i;
                if (status){
                    new AlertDialog.Builder(MyCloset.this).setIcon(R.drawable.muelleimer).setTitle("Löschen").setMessage("Wollen sie das Kleidungsstück entfernen?")
                            .setPositiveButton("Ja", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dbConnector.update("BenutzerID", "Seriennummer", "Chips", "'" + String.valueOf(sNummern.get(element)) + "'", "'0'");
                                    bezeichnungen.remove(element);
                                    sNummern.remove(element);
                                    customAdapter.notifyDataSetChanged();
                                }
                            })
                            .setNegativeButton("Nein", null).show();
                    return true;
                }
                return false;
            }
        });

        //Zurück Button OnClickListener
        zurueck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                status = false;

                gridView.setAdapter(customAdapter);
                z = 0;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);

        MenuItem menuItem = menu.findItem(R.id.suche);
        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setQueryHint("Name des Kleidungsstücks");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    //BottomSheet aufrufen
    private void extendSheet(String bezeichnungText, String markeText, String colorText, String sizeText, String herkunftText, String datum) {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(
                MyCloset.this, R.style.BottomSheetDialogTheme
        );
        View bottomSheetView = LayoutInflater.from(getApplicationContext())
                .inflate(
                        R.layout.layout_bottom_sheet,
                        null
                );
        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();
        LinearLayout ll = bottomSheetView.findViewById(R.id.bottomSheetContainer);
        //Textfelder identifzieren
        TextView tvBezeichnung = ll.findViewById(R.id.tvBezeichnung);
        TextView tvMarke = ll.findViewById(R.id.tvMarke);
        TextView tvColor = ll.findViewById(R.id.tvColor);
        TextView tvSize = ll.findViewById(R.id.tvSize);
        TextView tvHerkunft = ll.findViewById(R.id.tvHerkunft);
        TextView tvDatum = ll.findViewById(R.id.datum);
        Button add = ll.findViewById(R.id.addToCloset);
        add.setVisibility(View.INVISIBLE);
        tvBezeichnung.setText(bezeichnungText);
        tvMarke.setText(markeText);
        tvColor.setText(colorText);
        tvSize.setText(sizeText);
        tvDatum.setText(datum);
        tvHerkunft.setText("Made in " + herkunftText);
    }

    //String: Parameter an doInBackground; Void: Parameter an publishProgress bzw. onProgressUpdate; String[]: Parameter von doInBackground an onPostExecute
    //ASyncTask zur Datenbank Verbindung, sodass im main-thread was anderes weiter laufen kann
    private class DauertLange extends AsyncTask<String, Void, String[]> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Vorher");
        }

        @Override
        protected String[] doInBackground(String... pStrings) {
            //publishProgress();
            String sN = pStrings[0];
            String tN = pStrings[1];
            String bd = pStrings[2];
            String z = pStrings[3];
            String[] ausgabe = dbConnector.select(sN, tN, bd, z);

            return ausgabe;
        }

        protected void onPostExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Nacher");
        }
    }

    //GridView Adapter Klasse
    private class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            int r = 0;
            if (status) {
                String[] werte = new String[0];
                if (kategorien[kategorie].equals("Gesamte Kleidung")) {
                    try {
                        werte = new DauertLange().execute("Kleidungstypen.Bezeichnung, Kleidungstypen.Seriennummer", "Kleidungstypen INNER JOIN Chips ON Kleidungstypen.Seriennummer = Chips.Seriennummer", "Chips.BenutzerID = '" + main.aBenutzerID + "'", "2").get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    for (int g = 0; g < werte.length; g++) {
                        if (g % 2 == 0) {
                            bezeichnungen.add(werte[g]);
                        } else {
                            sNummern.add(werte[g]);
                        }
                    }
                } else {
                    try {
                        werte = new DauertLange().execute("Kleidungstypen.Bezeichnung, Kleidungstypen.Seriennummer", "Kleidungstypen INNER JOIN Chips ON Kleidungstypen.Seriennummer = Chips.Seriennummer", "Chips.BenutzerID = '" + main.aBenutzerID + "' AND Art = '" + kategorien[kategorie] + "'", "2").get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println(werte[0]);
                    for (int g = 0; g < werte.length; g++) {
                        if (g % 2 == 0) {
                            bezeichnungen.add(werte[g]);
                        } else {
                            sNummern.add(werte[g]);
                        }
                    }
                }
                r = werte.length/2;
            } else {
                r = kategorien.length;
            }
            return r;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        //Darstellung wird erstellt und Textfeld und Bild mit Daten gefüllt
        public View getView(int i, View view, ViewGroup viewGroup) {
            View view1 = null;
            if (status) {
                view1 = getLayoutInflater().inflate(R.layout.grid_element, null);
                TextView bezeichnung = view1.findViewById(R.id.item_name);
                ImageView bild = view1.findViewById(R.id.grid_image);

                zurueck.setVisibility(View.VISIBLE);
                bezeichnung.setText(bezeichnungen.get(i));
                bild.setImageResource(R.drawable.tshirt);
                //z++;
                return view1;

            } else if (!status) {
                view1 = getLayoutInflater().inflate(R.layout.kategorie_element, null);
                TextView bezeichnung = view1.findViewById(R.id.item_name);
                ImageView bild = view1.findViewById(R.id.grid_image);


                zurueck.setVisibility(View.INVISIBLE);
                bezeichnung.setText(kategorien[i]);
                bild.setImageResource(kIcons[i]);

                return view1;
            }

            return view1;
        }
    }


}