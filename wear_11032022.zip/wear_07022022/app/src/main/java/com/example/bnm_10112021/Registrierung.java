package com.example.bnm_10112021;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;
import java.util.concurrent.ExecutionException;

public class Registrierung extends AppCompatActivity {

    DatabaseConnection dbConnector = new DatabaseConnection();
    MainActivity main = new MainActivity();

    int benutzerID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrierung);

        EditText username = (EditText) findViewById(R.id.usernameR);
        EditText email = (EditText) findViewById(R.id.emailR);
        EditText emailB = (EditText) findViewById(R.id.emailB);
        EditText passwort = (EditText) findViewById(R.id.passwort);
        EditText passwortB = (EditText) findViewById(R.id.passwortB);
        Button zurueckButton = (Button) findViewById(R.id.registrierungZurueck);
        Button weiterButton = (Button) findViewById(R.id.registrierungWeiter);
        TextView passwortFehler = (TextView) findViewById(R.id.passwortFehler);
        TextView emailFehler = (TextView) findViewById(R.id.emailFehler);

        weiterButton.setClickable(false);

        zurueckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Registrierung.this, MainActivity.class);
                startActivity(intent);

            }
        });

        /** if (username.getText() != null
         && one !=null
         && emailB.getText() !=null
         && passwort.getText() !=null
         && passwortB.getText() !=null){
         weiterButton.setClickable(true);
         }**/

        weiterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String one = String.valueOf(username.getText());
                String two = String.valueOf(email.getText());
                String three = String.valueOf(emailB.getText());
                String four = String.valueOf(passwort.getText());
                String five = String.valueOf(passwortB.getText());
                if (five.equals(four)) {
                    if (three.equals(two)) {

                        dbConnector.insert("Benutzerdaten", "Benutzername, BenutzerID, Email, Passwort", "('" + one + "', '" + bIdGenerieren() + "', '" + two + "', '" + four + "')");
                        main.aBenutzerID = benutzerID;
                        Intent intent = new Intent(Registrierung.this, Scan.class);
                        startActivity(intent);
                    } else {
                        emailFehler.setVisibility(View.VISIBLE);
                    }

                } else {
                    if (three.equals(two)) {
                        passwortFehler.setVisibility(View.VISIBLE);
                    } else {

                        passwortFehler.setVisibility(View.VISIBLE);
                        emailFehler.setVisibility(View.VISIBLE);
                    }
                }
                //Intent intent = new Intent(Registrierung.this, Scan.class);
                //startActivity(intent);

            }
        });
    }

    //Generiert eine BenutzerID zwischen 0 und 100 und gibt diese zurück
    public int bIdGenerieren() {
        Random random = new Random();
        benutzerID = random.nextInt(100);
        //Überprüft ob die ID schon vergeben ist
        String[] check = new String[0];
        try {
            check = new DauertLange().execute("BenutzerID", "Benutzerdaten", "1", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < check.length; i++) {
            if (String.valueOf(benutzerID).equals(check[i])) {
                bIdGenerieren();
            }
        }
        return benutzerID;
    }

    //ASyncTask zur Datenbank Verbindung, sodass im main-thread was anderes weiter laufen kann
    private class DauertLange extends AsyncTask<String, Void, String[]> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Vorher");
        }

        @Override
        protected String[] doInBackground(String... pStrings) {
            //publishProgress();
            String sN = pStrings[0];
            String tN = pStrings[1];
            String bd = pStrings[2];
            String z = pStrings[3];
            String[] ausgabe = dbConnector.select(sN, tN, bd, z);
            return ausgabe;
        }

        protected void onPostExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Nacher");
        }
    }

}

