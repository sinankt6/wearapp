package com.example.bnm_10112021;

public class UserInformation {

    private int userID;
    private UserInformation(){
        userID = 1;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    private static UserInformation userInfo;
    public static UserInformation get(){
        if(userInfo == null){
            userInfo = new UserInformation();
        }
        return userInfo;
    }

    //int u = UserInformation.get().getUserID();
}

