package com.example.bnm_10112021;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.ExecutionException;


public class Login extends AppCompatActivity {

    DatabaseConnection dbConnector = new DatabaseConnection();
    MainActivity main = new MainActivity();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        com.example.bnm_10112021.DatabaseConnection dbConnection = new com.example.bnm_10112021.DatabaseConnection();

        EditText usernameL = (EditText) findViewById(R.id.usernameL);
        EditText passwortL = (EditText) findViewById(R.id.passwortL);
        Button zurueckButton = (Button) findViewById(R.id.loginZurueck);
        Button weiterButton = (Button) findViewById(R.id.loginWeiter);
        Button pVergessen = (Button) findViewById(R.id.pVergessen);

        zurueckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, MainActivity.class);
                startActivity(intent);
            }
        });

        weiterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String one = String.valueOf(usernameL.getText());
                String two = String.valueOf(passwortL.getText());

                String[] rueckgabe = new String[0];
                try {
                    rueckgabe = new DauertLange().execute("Benutzername, Passwort", "Benutzerdaten","1","2").get();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //Check ob Passwort und Nutzername existieren und richtig sind
                for (int i = 0; i<rueckgabe.length/2; i += 2){
                    if (rueckgabe[i].equals(one)){
                        if (rueckgabe[i+1].equals(two)){
                            String[] jbenutzerID = new String[0];
                            try {
                                jbenutzerID = new DauertLange().execute("BenutzerID", "Benutzerdaten", "Benutzername = '" + rueckgabe[i] + "'", "1").get();
                            } catch (ExecutionException e) {
                                e.printStackTrace();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            System.out.println(Integer.valueOf(jbenutzerID[0]));
                            main.aBenutzerID = Integer.valueOf(jbenutzerID[0]);
                            Toast.makeText(getApplicationContext(), "Eingeloggt!", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(Login.this, Scan.class);
                            startActivity(intent);
                            return;
                        } else{
                            Toast.makeText(getApplicationContext(), "Das Passwort spricht nicht mit dem Nutzernamen überein!", Toast.LENGTH_LONG).show();
                        }
                    } else{
                        // Toast.makeText(getApplicationContext(), "Der Nutzername ist noch nicht vergeben!", Toast.LENGTH_LONG).show();
                    }
                }

            }
        });

        pVergessen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Login.this, PasswortVergessen.class);
                startActivity(intent);
            }
        });

    }

    //String: Parameter an doInBackground; Void: Parameter an publishProgress bzw. onProgressUpdate; String[]: Parameter von doInBackground an onPostExecute
    //ASyncTask zur Datenbank Verbindung, sodass im main-thread was anderes weiter laufen kann
    private class DauertLange extends AsyncTask<String, Void, String[]> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Vorher");
        }

        @Override
        protected String[] doInBackground(String... pStrings) {
            //publishProgress();
            String sN = pStrings[0];
            String tN = pStrings[1];
            String bd = pStrings[2];
            String z = pStrings[3];
            String[] ausgabe = dbConnector.select(sN, tN, bd, z);

            return ausgabe;
        }

        protected void onPostExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Nacher");
        }
    }

}
