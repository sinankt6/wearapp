package com.example.bnm_10112021;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.navigation.NavigationBarView;

import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;


public class MyCloset extends AppCompatActivity {



    //Initalisierung von Variablen
    ArrayList<String> sNummern = new ArrayList<>();
    ArrayList<String> bezeichnungen = new ArrayList<>();
    ArrayList<Bitmap> bilder = new ArrayList<>();

    //Arrays mit der Bezeichnung und den Bildern zu den Kategorien
    String[] kategorien = {"TShirts", "Sweatshirts", "Kapuzenpullover", "Zip-Hoodie", "Hosen", "Kurze Hosen", "Jacken", "Kleider", "Gesamte Kleidung"};
    int[] kIcons = {R.drawable.tshirts, R.drawable.sweatshirt, R.drawable.hoodie, R.drawable.kapuzenjacke, R.drawable.hose, R.drawable.shorts, R.drawable.jacke, R.drawable.kleid, R.drawable.tshirt};
    int[] aktiveKategorien = new int[0];

    /** false -> Kategorien und true -> Kleidungsstücke**/
    Boolean status = false;

    Button zurueck;
    int kategorie;

    int z = 0;
    //Zaehler für Anzahl an GridView Elementen
    int r = 0;


    MainActivity main;

    ViewSwitcher profileSwitcher;

    private CheckBox cb0, cb1, cb2, cb3, cb4, cb5, cb6, cb7;
    ArrayList<String>aKategorien;
    ArrayList<Integer> icons;

    Button bSettings;
    Button zurueck2;

    Context c;

    BottomNavigationView bottomNavigationItemView;
    //Objekt der Klasse DatabaseConnection wird erstellt
    DatabaseConnection dbConnector = new DatabaseConnection();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_closet);
        bottomNavigationItemView = findViewById(R.id.navigator);
        bottomNavigationItemView.setSelectedItemId(R.id.mycloset);

        main = new MainActivity();

        c = this;

        profileSwitcher = (ViewSwitcher) findViewById(R.id.profileSwitcher);

        cb0 = (CheckBox) findViewById(R.id.cb0);
        cb1 = (CheckBox) findViewById(R.id.cb1);
        cb2 = (CheckBox) findViewById(R.id.cb2);
        cb3 = (CheckBox) findViewById(R.id.cb3);
        cb4 = (CheckBox) findViewById(R.id.cb4);
        cb5 = (CheckBox) findViewById(R.id.cb5);
        cb6 = (CheckBox) findViewById(R.id.cb6);
        cb7 = (CheckBox) findViewById(R.id.cb7);

        aKategorien = new ArrayList<>(Arrays.asList("Gesamte Kleidung","TShirts", "Sweatshirts", "Kapuzenpullover", "Zip-Hoodie", "Jeans", "Kurze Hosen", "Jacken", "Kleider"));
        icons = new ArrayList<>(Arrays.asList(R.drawable.gesamte_kleidung, R.drawable.tshirts, R.drawable.sweatshirt, R.drawable.hoodie, R.drawable.kapuzenjacke, R.drawable.hose, R.drawable.shorts, R.drawable.jacke, R.drawable.kleid));

        bSettings = (Button) findViewById(R.id.bSettings);
        zurueck2 = (Button) findViewById(R.id.zurueck2);

        //DOKU, VERALTET!!!!

        //OnItemSelectedListener vom Bottom Navigation Menü
        bottomNavigationItemView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                switch (id) {
                    case R.id.settings:
                        startActivity(new Intent(getApplicationContext(), Settings.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.stats:
                        startActivity(new Intent(getApplicationContext(), Statistics.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.scan:
                        startActivity(new Intent(getApplicationContext(), Scan.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.wash:
                        startActivity(new Intent(getApplicationContext(), Wash.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.mycloset:
                        return true;
                }
                return false;
            }
        });



        GridView gridView = (GridView) findViewById(R.id.gridView);
        zurueck = (Button) findViewById(R.id.zurueck1);
        CustomAdapter customAdapter = new CustomAdapter();

        //Namen und Seriennnumern der Kleidungsstücke werden aus der Datenbank abgerufen und im Array werte gespeichert


        //dem gridView wird der Adapter customAdapter zugewiesen
        gridView.setAdapter(customAdapter);

        //GridView OnItemClickListener
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //if-else-Verzweigung, je nachdem welche Seite aktiv ist (Kategorien oder genaue Kleidungsstücke)
                if (status) {
                    String[] rueckgabe = new String[0];
                    try {
                        rueckgabe = new DauertLange().execute("Bezeichnung, Marke, Farbe, Size, Herkunft", "Kleidungstypen", "Seriennummer = '" + sNummern.get(i) + "'", "5").get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    String[] rueckgabe2 = new String[0];
                    try {
                        rueckgabe2 = new DauertLange().execute("Kaufdatum", "Chips", "Seriennummer = '" + sNummern.get(i) + "'","1").get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    LocalDate datumHeute = LocalDate.now();
                    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate localDate = LocalDate.parse(rueckgabe2[0], dateTimeFormatter);
                    Duration diff = Duration.between(localDate.atStartOfDay(), datumHeute.atStartOfDay());
                    int tage = (int) diff.toDays();
                    String datumsZeile = rueckgabe2[0] + " // Tage seit Kauf: " + tage;
                    //Bottom Sheet wird aufgerufen und mit Werten aus der DB befüllt
                    extendSheet(rueckgabe[0], rueckgabe[1], rueckgabe[2], rueckgabe[3], rueckgabe[4], datumsZeile);
                } else if (!status) {
                    kategorie = i;
                    customAdapter.notifyDataSetChanged();
                    z = 0;
                    status = true;
                    zurueck.setVisibility(View.VISIBLE);
                    bSettings.setVisibility(View.INVISIBLE);
                }
            }
        });

        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                int element = i;
                if (status){
                    new AlertDialog.Builder(MyCloset.this).setIcon(R.drawable.muelleimer).setTitle("Löschen").setMessage("Wollen sie das Kleidungsstück entfernen?")
                            .setPositiveButton("Ja", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dbConnector.update("BenutzerID", "Seriennummer", "Chips", "'" + String.valueOf(aKategorien.get(element)) + "'", "'0'");
                                    bezeichnungen.remove(element);
                                    sNummern.remove(element);
                                    customAdapter.notifyDataSetChanged();
                                }
                            })
                            .setNegativeButton("Nein", null).show();
                    return true;
                }
                return false;
            }
        });

        //Zurück Button OnClickListener
        zurueck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                status = false;

                gridView.setAdapter(customAdapter);
                z = 0;
            }
        });

        //Settings Button OnClickListener
        bSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cb0.setText(kategorien[0]);
                cb1.setText(kategorien[1]);
                cb2.setText(kategorien[2]);
                cb3.setText(kategorien[3]);
                cb4.setText(kategorien[4]);
                cb5.setText(kategorien[5]);
                cb6.setText(kategorien[6]);
                cb7.setText(kategorien[7]);
                zurueck2.setVisibility(View.VISIBLE);
                profileSwitcher.showNext();
            }
        });

        //Zurück2 Button OnClickListener
        zurueck2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customAdapter.notifyDataSetChanged();
                profileSwitcher.showPrevious();
            }
        });

        //OnClickListener für jede Checkbox
        cb0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb0.isChecked()){
                    aKategorien.add((String) cb0.getText());
                    icons.add(R.drawable.tshirts);
                } else{
                    aKategorien.remove(cb0.getText());
                    System.out.println(icons.get(0));
                    icons.remove(1);
                }
            }
        });
        cb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb1.isChecked()){
                    aKategorien.add((String) cb1.getText());
                    icons.add(R.drawable.sweatshirt);
                } else{
                    aKategorien.remove(cb1.getText());
                    System.out.println(icons.get(1));
                    icons.remove(2);
                }
            }
        });
        cb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb2.isChecked()){
                    aKategorien.add((String) cb2.getText());
                    icons.add(R.drawable.hoodie);
                } else{
                    aKategorien.remove(cb2.getText());
                    System.out.println(icons.get(2));
                    icons.remove(3);
                }
            }
        });
        cb3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb3.isChecked()){
                    aKategorien.add((String) cb3.getText());
                    icons.add(R.drawable.sweatshirt);
                } else{
                    aKategorien.remove(cb3.getText());
                    System.out.println(icons.get(3));
                    icons.remove(4);
                }
            }
        });
        cb4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb4.isChecked()){
                    aKategorien.add((String) cb4.getText());
                    icons.add(R.drawable.hose);
                } else{
                    aKategorien.remove(cb4.getText());
                    System.out.println(icons.get(4));
                    icons.remove(5);
                }
            }
        });
        cb5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb5.isChecked()){
                    aKategorien.add((String) cb5.getText());
                    icons.add(R.drawable.shorts);
                } else{
                    aKategorien.remove(cb5.getText());
                    System.out.println(icons.get(5));
                    icons.remove(6);
                }
            }
        });
        cb6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb6.isChecked()){
                    aKategorien.add((String) cb6.getText());
                    icons.add(R.drawable.jacke);
                } else{
                    aKategorien.remove(cb6.getText());
                    System.out.println(icons.get(6));
                    icons.remove(7);
                }
            }
        });
        cb7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb7.isChecked()){
                    aKategorien.add((String) cb7.getText());
                    icons.add(R.drawable.kleid);
                } else{
                    aKategorien.remove(cb7.getText());
                    System.out.println(icons.get(7));
                    icons.remove(8);
                }
            }
        });
    }


    //BottomSheet aufrufen
    private void extendSheet(String bezeichnungText, String markeText, String colorText, String sizeText, String herkunftText, String datum) {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(
                MyCloset.this, R.style.BottomSheetDialogTheme
        );
        View bottomSheetView = LayoutInflater.from(getApplicationContext())
                .inflate(
                        R.layout.layout_bottom_sheet,
                        null
                );
        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();
        LinearLayout ll = bottomSheetView.findViewById(R.id.bottomSheetContainer);
        //Textfelder identifzieren
        TextView tvBezeichnung = ll.findViewById(R.id.tvBezeichnung);
        TextView tvMarke = ll.findViewById(R.id.tvMarke);
        TextView tvColor = ll.findViewById(R.id.tvColor);
        TextView tvSize = ll.findViewById(R.id.tvSize);
        TextView tvHerkunft = ll.findViewById(R.id.tvHerkunft);
        TextView tvDatum = ll.findViewById(R.id.datum);
        Button add = ll.findViewById(R.id.addToCloset);
        add.setVisibility(View.INVISIBLE);
        tvBezeichnung.setText(bezeichnungText);
        tvMarke.setText(markeText);
        tvColor.setText(colorText);
        tvSize.setText(sizeText);
        tvDatum.setText(datum);
        tvHerkunft.setText("Made in " + herkunftText);
    }

    //String: Parameter an doInBackground; Void: Parameter an publishProgress bzw. onProgressUpdate; String[]: Parameter von doInBackground an onPostExecute
    //ASyncTask zur Datenbank Verbindung, sodass im main-thread was anderes weiter laufen kann
    private class DauertLange extends AsyncTask<String, Void, String[]> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Vorher");
        }

        @Override
        protected String[] doInBackground(String... pStrings) {
            //publishProgress();
            String sN = pStrings[0];
            String tN = pStrings[1];
            String bd = pStrings[2];
            String z = pStrings[3];
            String[] ausgabe = dbConnector.select(sN, tN, bd, z);

            return ausgabe;
        }

        protected void onPostExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Nacher");
        }
    }

    //AsyncTask zum Laden der Bilder
    private class LoadImage extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground (String...strings) {
            int sN = Integer.parseInt(strings[0]);
            String[] rueckgabe = dbConnector.select("Bild", "Kleidungstypen", "Seriennummer IN (" + sN + ")", "1");
            System.out.println(rueckgabe[0] + "JOOOO");
            String urlLink = "https://wear.bplaced.net/images/" + rueckgabe[0];
            Bitmap bitmap = null;
            try {
                InputStream inputStream = new java.net.URL(urlLink).openStream();
                bitmap = BitmapFactory.decodeStream(inputStream);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return bitmap;
        }
    }

    //GridView Adapter Klasse
    private class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            //alte Daten lokal löschen
            bezeichnungen.clear();
            sNummern.clear();
            bilder.clear();
            //status entspricht, wenn man sich in der Übersicht der Kategorien befindet
            if (status) {
                String[] werte = new String[0];
                if (aKategorien.get(kategorie).equals("Gesamte Kleidung")) {
                    try {
                        werte = new DauertLange().execute("Kleidungstypen.Bezeichnung, Kleidungstypen.Seriennummer", "Kleidungstypen INNER JOIN Chips ON Kleidungstypen.Seriennummer = Chips.Seriennummer", "Chips.BenutzerID = '" + UserInformation.get().getUserID() + "' AND Kleidungstypen.Seriennummer != 0", "2").get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    for (int g = 0; g < werte.length; g++) {
                        if (g % 2 == 0) {
                            bezeichnungen.add(werte[g]);
                        } else {
                            sNummern.add(werte[g]);
                        }
                    }
                } else {
                    try {
                        werte = new DauertLange().execute("Kleidungstypen.Bezeichnung, Kleidungstypen.Seriennummer", "Kleidungstypen INNER JOIN Chips ON Kleidungstypen.Seriennummer = Chips.Seriennummer", "Chips.BenutzerID = '" + UserInformation.get().getUserID() + "' AND Art = '" + aKategorien.get(kategorie) + "' AND Kleidungstypen.Seriennummer != 0", "2").get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    for (int g = 0; g < werte.length; g++) {
                        if (g % 2 == 0) {
                            bezeichnungen.add(werte[g]);
                        } else {
                            sNummern.add(werte[g]);
                        }
                    }
                }
                r = werte.length/2;
            } else {
                r = aKategorien.toArray().length;
            }
            System.out.println("Anzahl: " + r);
            if (r == 0){
                Toast.makeText(c, "Sie haben keine Kleidungsstücke dieser Kategorie!", Toast.LENGTH_LONG).show();
            }
            for (int i = 0; i < sNummern.toArray().length; i++) {
                Bitmap b = null;
                try {
                    b = new LoadImage().execute(sNummern.get(i)).get();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                bilder.add(b);
            }
            return r;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        //Darstellung wird erstellt und Textfeld und Bild mit Daten gefüllt
        public View getView(int i, View view, ViewGroup viewGroup) {
            View view1 = null;

            if (status) {
                view1 = getLayoutInflater().inflate(R.layout.grid_element, null);
                TextView bezeichnung = view1.findViewById(R.id.item_name);
                ImageView bild = view1.findViewById(R.id.grid_image);
                view1.setBackgroundResource(R.drawable.scan_gridelement_background);


                zurueck.setVisibility(View.VISIBLE);
                bezeichnung.setText(bezeichnungen.get(i));
                bild.setImageBitmap(bilder.get(i));

                return view1;

            } else if (!status) {
                view1 = getLayoutInflater().inflate(R.layout.grid_element, null);
                TextView bezeichnung = view1.findViewById(R.id.item_name);
                ImageView bild = view1.findViewById(R.id.grid_image);


                zurueck.setVisibility(View.INVISIBLE);
                bSettings.setVisibility(View.VISIBLE);

                try {
                    bezeichnung.setText(aKategorien.get(i));
                } catch (IndexOutOfBoundsException e){}
                try {
                    bild.setImageResource(icons.get(i));
                } catch (IndexOutOfBoundsException e){}
                view1.setBackgroundResource(R.drawable.scan_gridelement_background);

                return view1;
            }

            return view1;
        }
    }


}