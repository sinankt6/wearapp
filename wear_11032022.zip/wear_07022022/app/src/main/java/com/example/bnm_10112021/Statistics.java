package com.example.bnm_10112021;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.app.AlertDialog;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;


import java.util.ArrayList;
import java.util.List;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Pie;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.LegendRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutionException;

public class Statistics extends AppCompatActivity {

    BottomNavigationView bottomNavigationItemView;

    DatabaseConnection dbConnector;
    MainActivity main;
    TextView waschungen;
    TextView duTage;
    TextView dAuslastung;
    TextView bewertungstext;

    int section1Frontend = 0;
    int section2Frontend = 0;
    int section3Frontend = 0;
    int section4Frontend = 0;
    int section5Frontend = 0;
    int finalFrontend = 0;

    ProgressBar progressBar1;
    ProgressBar progressBar2;
    ProgressBar progressBar3;
    ProgressBar progressBar4;
    ProgressBar progressBar5;
    ProgressBar progressBar;


    Button basicInformation;
    Button chartAnalysis;
    Button FtiAverages;

    //View awView;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        dbConnector = new DatabaseConnection();
        main = new MainActivity();

        waschungen = (TextView) findViewById(R.id.anzahlWaschungen);
        duTage = (TextView) findViewById(R.id.dTage);
        dAuslastung = (TextView) findViewById(R.id.dAuslastung);


        bottomNavigationItemView = findViewById(R.id.navigator);
        bottomNavigationItemView.setSelectedItemId(R.id.stats);

        //DOKU, VERALTET!!!!
        bottomNavigationItemView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                switch (id) {
                    case R.id.settings:
                        startActivity(new Intent(getApplicationContext(), Settings.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.stats:
                        return true;
                    case R.id.scan:
                        startActivity(new Intent(getApplicationContext(), Scan.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.wash:
                        startActivity(new Intent(getApplicationContext(), Wash.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.mycloset:
                        startActivity(new Intent(getApplicationContext(), MyCloset.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });

        //Entwicklung der prozentualen Auslastung des Aktiven Benutzers
        String[] pAuslastungen = new String[0];
        try {
            pAuslastungen = new DauertLange().execute("Datum, Auslastung", "Entwicklung", "BenutzerID = '" + main.aBenutzerID + "'", "2").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ArrayList<String> daten = new ArrayList<>();
        ArrayList<String> auslastungen = new ArrayList<>();
        LocalDate aktuell = LocalDate.now();
        DateTimeFormatter dateformat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        long zeit = 0;
        int[] wochen = new int[10];
        int woche1 = 0, woche2 = 0, woche3 = 0, woche4 = 0, woche5 = 0, woche6 = 0, woche7 = 0, woche8 = 0, woche9 = 0, woche10 = 0;
        for (int i = 0; i < pAuslastungen.length; i++) {
            if (i % 2 == 0) {
                LocalDate localDate = LocalDate.parse(pAuslastungen[i], dateformat);
                Duration diff = Duration.between(localDate.atStartOfDay(), aktuell.atStartOfDay());
                zeit = diff.toDays();
                System.out.println(zeit + "z");
                if (zeit <= 7) {
                    //daten.add(pAuslastungen[i]);
                    woche1 += Integer.valueOf(pAuslastungen[i+1]);
                    wochen[0]++;
                }
                else if (zeit > 8 && zeit <=14){
                    woche2 += Integer.valueOf(pAuslastungen[i+1]);
                    wochen[1]++;
                }
                else if (zeit > 14 && zeit <=21){
                    woche3 += Integer.valueOf(pAuslastungen[i+1]);
                    wochen[2]++;
                }
                else if (zeit > 21 && zeit <=28){
                    woche4 += Integer.valueOf(pAuslastungen[i+1]);
                    wochen[3]++;
                }
                else if (zeit > 28 && zeit <=35){
                    woche5 += Integer.valueOf(pAuslastungen[i+1]);
                    wochen[4]++;
                }
                else if (zeit > 35 && zeit <=42){
                    woche6 += Integer.valueOf(pAuslastungen[i+1]);
                    wochen[5]++;
                }
                else if (zeit >42 && zeit <=49){
                    woche7 += Integer.valueOf(pAuslastungen[i+1]);
                    wochen[6]++;
                }
                else if (zeit > 49 && zeit <=56){
                    woche8 += Integer.valueOf(pAuslastungen[i+1]);
                    wochen[7]++;
                }
                else if (zeit > 56 && zeit <=63){
                    woche9 += Integer.valueOf(pAuslastungen[i+1]);
                    wochen[8]++;
                }
                else if (zeit > 63 && zeit <=70){
                    woche10 += Integer.valueOf(pAuslastungen[i+1]);
                    wochen[9]++;
                }
            }
        }

        /**Durschnitte der 7 Tage werden berechnet und falls nicht in den Tagen gewaschen
         * wurde wird die Fehlermeldung gecatcht
         */
        try{
            woche1 = woche1 / wochen[0];
        }catch (ArithmeticException e) {}
        try{
            woche2 = woche2 / wochen[1];
        }catch (ArithmeticException e) {}
        try{
            woche3 = woche3 / wochen[2];
        }catch (ArithmeticException e) {}
        try{
            woche4 = woche4 / wochen[3];
        }catch (ArithmeticException e) {}
        try{
            woche5 = woche5 / wochen[4];
        }catch (ArithmeticException e) {}
        try{
            woche6 = woche6 / wochen[5];
        }catch (ArithmeticException e) {}
        try{
            woche7 = woche7 / wochen[6];
        }catch (ArithmeticException e) {}
        try{
            woche8 = woche8 / wochen[7];
        }catch (ArithmeticException e) {}
        try{
            woche9 = woche9 / wochen[8];
        }catch (ArithmeticException e) {}
        try{
            woche10 = woche10 / wochen[9];
        }catch (ArithmeticException e) {}



        //Durchschnittliche prozentuale Auslastung aller Benutzer
        String[] pAuslastungenAvg = new String[0];
        try {
            pAuslastungenAvg = new DauertLange().execute("Datum, Auslastung", "Entwicklung", "1", "2").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ArrayList<String> datenAvg = new ArrayList<>();
        ArrayList<String> auslastungenAvg = new ArrayList<>();
        LocalDate aktuellAvg = LocalDate.now();
        DateTimeFormatter dateformatAvg = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        long zeitAvg = 0;
        int wocheAvg = 0;
        int zaehler = 0;
        for (int i = 0; i < pAuslastungenAvg.length; i++) {
            if (i % 2 == 0) {
                LocalDate localDateAvg = LocalDate.parse(pAuslastungenAvg[i], dateformatAvg);
                Duration diff = Duration.between(localDateAvg.atStartOfDay(), aktuell.atStartOfDay());
                zeit = diff.toDays();
                if (zeit <= 70) {
                    wocheAvg += Integer.valueOf(pAuslastungenAvg[i+1]);
                    zaehler ++;
                }
            }
        }
        wocheAvg = wocheAvg/zaehler;




        //Ausgabe der Anzahl von Waschmaschinen die der Nutzer über die App aktiviert hat
        String[] anzahlWaschungen = new String[0];
        try {
            anzahlWaschungen = new DauertLange().execute("Waschhaeufigkeit", "Chips", "BenutzerID = '" + main.aBenutzerID + "'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int aWaschung = 0;
        for (int i = 0; i < anzahlWaschungen.length; i++) {
            try {
                aWaschung += Integer.parseInt(anzahlWaschungen[i]);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }

        waschungen.setText(String.valueOf(aWaschung));

        //durchschnittliche Tage seit Kaufdatum
        String[] tage = new String[0];
        try {
            tage = new DauertLange().execute("Kaufdatum", "Chips", "BenutzerID = '" + main.aBenutzerID + "'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        LocalDate jetzt = LocalDate.now();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        long zt = 0;
        for (int i = 0; i < tage.length; i++) {
            if(!tage[i].equals("")) {
                LocalDate localDate = LocalDate.parse(tage[i], dtf);
                Duration diff = Duration.between(jetzt.atStartOfDay(), localDate.atStartOfDay());
                zt += (-1) * (diff.toDays());
            }
        }
        int dTage = (int) (zt / tage.length);

        duTage.setText(String.valueOf(dTage));

        //Ausgabe der durschnittlichen Auslastung der Waschmaschinen
        String[] auslastung = new String[1];
        try {
            auslastung = new DauertLange().execute("dAuslastung", "Benutzerdaten", "BenutzerID = '" + main.aBenutzerID + "'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        dAuslastung.setText(auslastung[0] + "%");

        //Orte der Herkunft
        String[] orte = new String[0];
        try {
            orte = new DauertLange().execute("Kleidungstypen.Herkunft", "Kleidungstypen INNER JOIN Chips ON Kleidungstypen.Seriennummer=Chips.Seriennummer", "BenutzerID = '" + main.aBenutzerID + "'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String[] orteGefiltert = new String[orte.length];
        Integer[] orteAnzahl = new Integer[orte.length];

        for (int i = 0; i < orteAnzahl.length; i++) {
            orteAnzahl[i] = 1;
        }
        //System.out.println("OREAKBJNLR: " + orteAZ[1].length);


        for (int i = 0; i < orte.length; i++) {
            //System.out.println("Kleidungsstück " + (i+1) + " wird überprüft.");
            for (int k = 0; k < orteGefiltert.length; k++) {
                //System.out.println("Überprüfung an stelle-k:"+ k);

                if (orteGefiltert[k] == null) {
                    orteGefiltert[k] = orte[i];
                    System.out.println("neue Eingabe: " + orteGefiltert[k]);
                    k = orteGefiltert.length;

                } else if (orteGefiltert[k].equals(orte[i])) {
                    System.out.println("DOPPLER!!");
                    System.out.println(orteAnzahl[k]);
                    orteAnzahl[k]++;
                    System.out.println(orteAnzahl[k]);
                    k = orteGefiltert.length;
                } else {
                    System.out.println("Stelle bereits gefüllt...");
                }

            }
        }
        List<DataEntry> data = new ArrayList<>();
        for (int p = 0; p < orteAnzahl.length; p++) {
            if (orteGefiltert[p] != null && !orteGefiltert[p].isEmpty()) {//https://stackoverflow.com/questions/2601978/how-to-check-if-my-string-is-equal-to-null
                data.add(new ValueDataEntry(orteGefiltert[p], orteAnzahl[p]));
                System.out.println(orteGefiltert[p] + "   " + orteAnzahl[p]);
            }
        }
        Pie pie = AnyChart.pie();
        pie.data(data);
        AnyChartView anyChartView = (AnyChartView) findViewById(R.id.any_chart_view);
        anyChartView.setChart(pie);


        //Entwicklungsgraphen erstellen
        GraphView graph = (GraphView) findViewById(R.id.graph);

        /**DataPoint dp1 = null, dp2 = null, dp3 = null, dp4  = null, dp5  = null, dp6  = null, dp7  = null, dp8  = null, dp9  = null, dp10  = null;
        DataPoint[] dp = new DataPoint[10];
        int[] anzahl = {woche1, woche2, woche3, woche4, woche5, woche6, woche7, woche8, woche9, woche10};
        int zaehler = 1;
        for (int i = 0; i<10; i++){
            if(wochen[i]>0){
                dp[i] = new DataPoint(zaehler, anzahl[i]);
            }
            zaehler ++;
        }**/

        System.out.println(woche4 + "  " +  woche6);
        //Punkte erstellen
        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(new DataPoint[]{
                new DataPoint(1, woche1),
                new DataPoint(2, woche2),
                new DataPoint(3, woche3),
                new DataPoint(4, woche4),
                new DataPoint(5, woche5),
                new DataPoint(6, woche6),
                new DataPoint(7, woche7),
                new DataPoint(8, woche8),
                new DataPoint(9, woche9),
                new DataPoint(10, woche10)
        });

        LineGraphSeries<DataPoint> seriesAvg = new LineGraphSeries<DataPoint>(new DataPoint[]{
                new DataPoint(0, wocheAvg),
                new DataPoint(10, wocheAvg),

        });
        graph.addSeries(seriesAvg);

        //LineGraphSeries<DataPoint> series = new LineGraphSeries<>();

        double y;
        /**
         //Maximale Anzahl der punkte im Graphen
         for (int x=0;x<90;x++){
         //y=Math.sin(2*x*0.2)-2*Math.sin(x*0.2);
         series.appendData(new DataPoint(x,y),true , 90 );
         }
         **/
        graph.addSeries(series);


        //Farbe, Bezeichnung, Radius der Punkte, Linienstärke

        series.setColor(Color.GREEN);
        series.setTitle("Verlauf deiner Auslastung der Waschmaschine");
        series.setDrawDataPoints(true);
        series.setDataPointsRadius(5);
        series.setThickness(10);

        seriesAvg.setColor(Color.BLUE);
        seriesAvg.setTitle("Durchschnittliche Auslastung aller Nutzer");
        seriesAvg.setDrawDataPoints(true);
        seriesAvg.setDataPointsRadius(5);
        seriesAvg.setThickness(5);

        //Beschriftung des Graphen
        graph.setTitle("Durchschnittliche Auslastung");
        graph.setTitleTextSize(60);
        graph.setTitleColor(Color.BLACK);
        //Legende des Graphen
        graph.getLegendRenderer().setVisible(true);
        graph.getLegendRenderer().setAlign(LegendRenderer.LegendAlign.TOP);

        //Achsenbeschriftung
        GridLabelRenderer gridLabel = graph.getGridLabelRenderer();
        gridLabel.setHorizontalAxisTitle("Zeitlicher Verlauf der letzten 10 Wochen");
        gridLabel.setHorizontalAxisTitleTextSize(30);
        gridLabel.setVerticalAxisTitle("Auslastung in %");
        gridLabel.setVerticalAxisTitleTextSize(30);

        //Definitionsbereich des Graphen festlegen
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setMinX(0);
        graph.getViewport().setMaxX(12);

        graph.getViewport().setYAxisBoundsManual(true);
        graph.getViewport().setMinY(0);
        graph.getViewport().setMaxY(110);

        //Zooms und Scrollen aktivieren
        graph.getViewport().setScalable(true);
        graph.getViewport().setScrollable(true);
        graph.getViewport().setScalableY(true);
        graph.getViewport().setScrollableY(true);






        /**
         System.out.println("------------------------------");
         System.out.println(orteAZ[0][1]);
         System.out.println(orteAZ[0][3]);

         if(orteAZ[0][1].equals("Deutschland")){
         System.out.println("Nummer 1 stimmt");
         }
         if(orteAZ[0][3].equals("Deutschland")){
         System.out.println("Nummer 2 stimmt");
         }
         System.out.println("------------------------------");
         **/


        /**--------------------- Berechnungen Prozente des Fashion Transparency Indices 2021 ---------------------**/


        //Durchschnittlicher Prozentsatz der jeweiligen Teilsektoren des FTI's
        //Sektor I:
        String[] psektor1 = new String[0];
        try {
            psektor1 = new DauertLange().execute("Marken.SECTION1", "Marken INNER JOIN Kleidungstypen ON Kleidungstypen.Marke=Marken.MarkenName INNER JOIN Chips ON Chips.Seriennummer=Kleidungstypen.Seriennummer", "BenutzerID = '" + main.aBenutzerID + "'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Double [] psektor1Edtd = new Double[psektor1.length];
        double sum1 = 0;
        double avg1;

        for (int i = 0; i < psektor1.length; i++) {
            StringBuffer sb = new StringBuffer(psektor1[i]); https://www.javatpoint.com/how-to-remove-last-character-from-string-in-java
            sb.deleteCharAt(sb.length()-1);
            String convert = sb.toString();//https://beginnersbook.com/2015/04/convert-stringbuffer-to-string/
            psektor1Edtd[i] = Double.parseDouble(convert);
            sum1 = sum1 + psektor1Edtd[i];
        }
        avg1 = sum1 / psektor1Edtd.length;

        System.out.println("sum: " + sum1);
        System.out.println("avg: " + avg1);

        progressBar1 = findViewById(R.id.barSection1Score);
        section1Frontend = (int) Math.round(avg1);
        System.out.println("section1Frontend: " + section1Frontend);
        progressBar1.setProgress(section1Frontend);

        TextView avg1text = (TextView) findViewById(R.id.averageScoreInformation1);
        String inputText1 = "On avarage you scored " + "<b>" + section1Frontend + "%" + "</b> " + ". For more information, click on the screen.";
        avg1text.setText(Html.fromHtml(inputText1));

        //Sektor II:
        String[] psektor2 = new String[0];
        try {
            psektor2 = new DauertLange().execute("Marken.SECTION2", "Marken INNER JOIN Kleidungstypen ON Kleidungstypen.Marke=Marken.MarkenName INNER JOIN Chips ON Chips.Seriennummer=Kleidungstypen.Seriennummer", "BenutzerID = '" + main.aBenutzerID + "'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Double [] psektor2Edtd = new Double[psektor2.length];
        double sum2 = 0;
        double avg2;

        for (int i = 0; i < psektor2.length; i++) {
            StringBuffer sb = new StringBuffer(psektor2[i]); https://www.javatpoint.com/how-to-remove-last-character-from-string-in-java
            sb.deleteCharAt(sb.length()-1);
            String convert = sb.toString();//https://beginnersbook.com/2015/04/convert-stringbuffer-to-string/
            psektor2Edtd[i] = Double.parseDouble(convert);
            sum2 = sum2 + psektor2Edtd[i];
        }
        avg2 = sum2 / psektor2Edtd.length;

        System.out.println("sum: " + sum2);
        System.out.println("avg: " + avg2);

        progressBar2 = findViewById(R.id.barSection2Score);
        section2Frontend = (int) Math.round(avg2);
        System.out.println("section2Frontend: " + section2Frontend);
        progressBar2.setProgress(section2Frontend);

        TextView avg2text = (TextView) findViewById(R.id.averageScoreInformation2);
        String inputText2 = "On avarage you scored " + "<b>" + section2Frontend + "%" + "</b> " + ". For more information, click on the screen.";
        avg2text.setText(Html.fromHtml(inputText2));

        //Sektor III:
        String[] psektor3 = new String[0];
        try {
            psektor3 = new DauertLange().execute("Marken.SECTION3", "Marken INNER JOIN Kleidungstypen ON Kleidungstypen.Marke=Marken.MarkenName INNER JOIN Chips ON Chips.Seriennummer=Kleidungstypen.Seriennummer", "BenutzerID = '" + main.aBenutzerID + "'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Double [] psektor3Edtd = new Double[psektor3.length];
        double sum3 = 0;
        double avg3;

        for (int i = 0; i < psektor3.length; i++) {
            StringBuffer sb = new StringBuffer(psektor3[i]); https://www.javatpoint.com/how-to-remove-last-character-from-string-in-java
            sb.deleteCharAt(sb.length()-1);
            String convert = sb.toString();//https://beginnersbook.com/2015/04/convert-stringbuffer-to-string/
            psektor3Edtd[i] = Double.parseDouble(convert);
            sum3 = sum3 + psektor3Edtd[i];
        }
        avg3 = sum3 / psektor3Edtd.length;

        System.out.println("sum: " + sum3);
        System.out.println("avg: " + avg3);

        progressBar3 = findViewById(R.id.barSection3Score);
        section3Frontend = (int) Math.round(avg3);
        System.out.println("section3Frontend: " + section3Frontend);
        progressBar3.setProgress(section3Frontend);

        TextView avg3text = (TextView) findViewById(R.id.averageScoreInformation3);
        String inputText3 = "On avarage you scored " + "<b>" + section3Frontend + "%" + "</b> " + ". For more information, click on the screen.";
        avg3text.setText(Html.fromHtml(inputText3));

        //Sektor IV:
        String[] psektor4 = new String[0];
        try {
            psektor4 = new DauertLange().execute("Marken.SECTION4", "Marken INNER JOIN Kleidungstypen ON Kleidungstypen.Marke=Marken.MarkenName INNER JOIN Chips ON Chips.Seriennummer=Kleidungstypen.Seriennummer", "BenutzerID = '" + main.aBenutzerID + "'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Double [] psektor4Edtd = new Double[psektor4.length];
        double sum4 = 0;
        double avg4;

        for (int i = 0; i < psektor4.length; i++) {
            StringBuffer sb = new StringBuffer(psektor4[i]); https://www.javatpoint.com/how-to-remove-last-character-from-string-in-java
            sb.deleteCharAt(sb.length()-1);
            String convert = sb.toString();//https://beginnersbook.com/2015/04/convert-stringbuffer-to-string/
            psektor4Edtd[i] = Double.parseDouble(convert);
            sum4 = sum4 + psektor4Edtd[i];
        }
        avg4 = sum4 / psektor4Edtd.length;

        System.out.println("sum: " + sum4);
        System.out.println("avg: " + avg4);

        progressBar4 = findViewById(R.id.barSection4Score);
        section4Frontend = (int) Math.round(avg4);
        System.out.println("section4Frontend: " + section4Frontend);
        progressBar4.setProgress(section4Frontend);

        TextView avg4text = (TextView) findViewById(R.id.averageScoreInformation4);
        String inputText4 = "On avarage you scored " + "<b>" + section4Frontend + "%" + "</b> " + ". For more information, click on the screen.";
        avg4text.setText(Html.fromHtml(inputText4));

        //Sektor V:
        String[] psektor5 = new String[0];
        try {
            psektor5 = new DauertLange().execute("Marken.SECTION5", "Marken INNER JOIN Kleidungstypen ON Kleidungstypen.Marke=Marken.MarkenName INNER JOIN Chips ON Chips.Seriennummer=Kleidungstypen.Seriennummer", "BenutzerID = '" + main.aBenutzerID + "'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Double [] psektor5Edtd = new Double[psektor5.length];
        double sum5 = 0;
        double avg5;

        for (int i = 0; i < psektor5.length; i++) {
            StringBuffer sb = new StringBuffer(psektor5[i]); https://www.javatpoint.com/how-to-remove-last-character-from-string-in-java
            sb.deleteCharAt(sb.length()-1);
            String convert = sb.toString();//https://beginnersbook.com/2015/04/convert-stringbuffer-to-string/
            psektor5Edtd[i] = Double.parseDouble(convert);
            sum5 = sum5 + psektor5Edtd[i];
        }
        avg5 = sum5 / psektor5Edtd.length;

        System.out.println("sum: " + sum5);
        System.out.println("avg: " + avg5);

        progressBar5 = findViewById(R.id.barSection5Score);
        section5Frontend = (int) Math.round(avg5);
        System.out.println("section5Frontend: " + section5Frontend);
        progressBar5.setProgress(section5Frontend);

        TextView avg5text = (TextView) findViewById(R.id.averageScoreInformation5);
        String inputText5 = "On avarage you scored " + "<b>" + section5Frontend + "%" + "</b> " + ". For more information, click on the screen.";
        avg5text.setText(Html.fromHtml(inputText5));

        //Prozente des finalen FTI's
        String[] prozente = new String[0];
        try {
            prozente = new DauertLange().execute("Marken.FINAL", "Marken INNER JOIN Kleidungstypen ON Kleidungstypen.Marke=Marken.MarkenName INNER JOIN Chips ON Chips.Seriennummer=Kleidungstypen.Seriennummer", "BenutzerID = '1'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Double [] prozenteA = new Double[prozente.length];
        double sum = 0;
        double avg;

        for (int i = 0; i < prozente.length; i++) {
            StringBuffer sb = new StringBuffer(prozente[i]); https://www.javatpoint.com/how-to-remove-last-character-from-string-in-java
            sb.deleteCharAt(sb.length()-1);
            String convert = sb.toString();//https://beginnersbook.com/2015/04/convert-stringbuffer-to-string/
            prozenteA[i] = Double.parseDouble(convert);
            sum = sum + prozenteA[i];
        }
        avg = sum / prozenteA.length;

        System.out.println("sum: " + sum);
        System.out.println("avg: " + avg);

        progressBar = findViewById(R.id.barFinalScore);
        finalFrontend = (int) Math.round(avg);
        System.out.println("FinalFrontend: " + finalFrontend);
        progressBar.setProgress(finalFrontend);

        bewertungstext = (TextView) findViewById(R.id.bewertungText);

        String bewertungstextTemplate = "";

        if(avg < 5.5){
            bewertungstextTemplate = "Brands scoring between 0-5% are disclosing nothing at all or a very limited number of policies, which tend to be related to the brand’s hiring practices or local community engagement activities.";
        }else if (avg >= 5.5 && avg < 10.5){
            bewertungstextTemplate = "Brands scoring between 6-10% are likely to be publishing some policies for both their employees and suppliers. Those closer to 10% are more likely to be publishing a basic supplier code of conduct, some information about their procedures and limited information about their supplier assessment process.";
        }else if (avg >= 10.5 && avg < 20.5){
            bewertungstextTemplate = "Brands scoring between 11-20% are likely to be publishing many policies for both employees and suppliers, some procedures and some information about their supplier assessment and remediation processes. These brands will most likely not be publishing supplier lists and won’t be sharing much information, if anything, about our Spotlight Issues: Covid-19 response; living wages; purchasing practices; unionisation and collective bargaining; gender and racial equality; sustainable sourcing and materials; overconsumption, waste and circularity; water and chemicals; decarbonisation, deforestation and regeneration; carbon emissions and energy use.";
        }else if (avg >= 20.5 && avg < 30.5){
            bewertungstextTemplate = "Brands scoring between 21-30% are likely to be publishing much more detailed information about their policies, procedures, governance, social and environmental goals and supplier assessment and remediation processes. These brands may be publishing a basic list of manufacturers only containing the factory name and address. These brands are unlikely to be sharing information about the outcomes of their supplier assessments or grievance channels. These brands will not be disclosing information on all of the Spotlight Issues but may touch upon a few.";
        }else if (avg >= 30.5 && avg < 40.5){
            bewertungstextTemplate = "Brands scoring between 31-40% are typically disclosing their first-tier manufacturers as well as detailed information about their policies, procedures, social and environmental goals, governance, supplier assessment and remediation processes. These brands are also more likely to be disclosing partial information on a few of the Spotlight Issues such as carbon emissions, gender equality, sustainable sourcing and materials and energy use.";
        }else if (avg >= 40.5 && avg < 50.5){
            bewertungstextTemplate = "Brands scoring 41-50% are likely to be publishing more detailed supplier lists, many will be publishing processing facilities as well as manufacturers, in addition to detailed information about their policies, procedures, social and environmental goals, governance, supplier assessments and remediation processes and some supplier assessment findings. These brands are also more likely to be addressing some Spotlight Issues, such as carbon emissions; gender equality; sustainable sourcing and materials; energy use, waste and circularity; decarbonisation; water and chemicals.";
        }else if (avg >= 50.5 && avg < 60.5){
            bewertungstextTemplate = "Brands scoring 51-60% are disclosing all of the information already described in the other ranges and will be publishing detailed supplier lists. These brands will be disclosing most human rights and environmental policies, procedures, social and environmental goals and information about their governance and due diligence processes. They will likely be publishing some detailed information about the findings of their supplier assessments. These brands will be addressing many of the Spotlight Issues such as such as carbon emissions; gender equality; sustainable sourcing and materials; energy use, waste and circularity; decarbonisation; water and chemicals; living wages; waste and circularity.";
        }else if (avg >= 60.5 && avg < 70.5){
            bewertungstextTemplate = "Brands scoring 61-70% are disclosing all of the information already described in the other ranges and will be publishing detailed supplier lists, which include manufacturers, processing facilities and some suppliers of raw materials such as cotton, wool or viscose. These brands will also be addressing most of the Spotlight Issues explained in previous ranges as well as racial equality; Covid-19 response; overconsumption; deforestation and regeneration; purchasing practices; unionisation and collective bargaining.";
        }else if (avg >= 70.5 && avg < 80.5){
            bewertungstextTemplate = "Brands scoring 71-80% are disclosing all of the information already described in the other ranges and will be publishing detailed supplier lists for manufacturers, processing facilities and suppliers of raw materials such as cotton, wool or viscose. These brands will be publishing detailed information about their due diligence processes and outcomes, supplier assessments and remediation findings. These brands will be sharing comparatively more comprehensive and detailed information and data than other brands in the Index on the Spotlight Issues but still missing significant disclosures on outcomes and impacts.";
        }else if (avg >= 80.5){
            bewertungstextTemplate = "No brands score above 80% but if they did these brands would be disclosing all of the information already described as well as publishing detailed information about supplier assessment and remediation findings for specific facilities. They would also be sharing detailed supplier lists for at least 95% of all suppliers from manufacturing right down to raw materials. These brands would be mapping social and environmental impacts into their financial business model and disclosing ample data on their use of sustainable materials and would provide the gender breakdown of job roles within their own operations and in the supply chain. We would be able to find detailed information about the company’s purchasing practices, the company’s approach and progress towards living wages for workers in their supply chain. These brands would be disclosing their carbon emissions, use of renewable energy and water footprint from their own operations right down to raw material level.";
        }

        String finalScore = "Overall, you scored " + "<b>" + finalFrontend + "%" + "</b> " + " on avarage. ";
        bewertungstext.setText(Html.fromHtml(finalScore + bewertungstextTemplate));

        ScrollView basicInformationView = findViewById(R.id.basicInformation_view);
        ScrollView chartAnalysisView = findViewById(R.id.chartAnalysis_view);
        ScrollView FTIView = findViewById(R.id.FTI_view);


        basicInformation = findViewById(R.id.basicInformation_button);
        basicInformation.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View view) {
                System.out.println("funktioniert: Button 1");
                basicInformation.setBackgroundColor(getResources().getColor(R.color.CPbuttonInteriorSelected));
                basicInformationView.setVisibility(View.VISIBLE);


                chartAnalysis.setBackgroundColor(getResources().getColor(R.color.CPbuttonUnselected));
                chartAnalysisView.setVisibility(View.INVISIBLE);

                FtiAverages.setBackgroundColor(getResources().getColor(R.color.CPbuttonUnselected));
                FTIView.setVisibility(View.INVISIBLE);

            }
        });

        chartAnalysis = findViewById(R.id.chartAnalysis_button);
        chartAnalysis.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View view) {
                System.out.println("funktioniert: Button 2");
                chartAnalysis.setBackgroundColor(getResources().getColor(R.color.CPbuttonInteriorSelected));
                chartAnalysisView.setVisibility(View.VISIBLE);


                basicInformation.setBackgroundColor(getResources().getColor(R.color.CPbuttonUnselected));
                basicInformationView.setVisibility(View.INVISIBLE);


                FtiAverages.setBackgroundColor(getResources().getColor(R.color.CPbuttonUnselected));
                FTIView.setVisibility(View.INVISIBLE);

            }
        });

        FtiAverages = findViewById(R.id.FtiAverages_button);
        FtiAverages.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View view) {
                System.out.println("funktioniert: Button 3");
                FtiAverages.setBackgroundColor(getResources().getColor(R.color.CPbuttonInteriorSelected));
                FTIView.setVisibility(View.VISIBLE);


                basicInformation.setBackgroundColor(getResources().getColor(R.color.CPbuttonUnselected));
                basicInformationView.setVisibility(View.INVISIBLE);

                chartAnalysis.setBackgroundColor(getResources().getColor(R.color.CPbuttonUnselected));
                chartAnalysisView.setVisibility(View.INVISIBLE);
            }
        });

        basicInformation.setBackgroundColor(getResources().getColor(R.color.CPbuttonInteriorSelected));
        basicInformationView.setVisibility(View.VISIBLE);

        chartAnalysis.setBackgroundColor(getResources().getColor(R.color.CPbuttonUnselected));
        chartAnalysisView.setVisibility(View.INVISIBLE);

        FtiAverages.setBackgroundColor(getResources().getColor(R.color.CPbuttonUnselected));
        FTIView.setVisibility(View.INVISIBLE);

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.fashionrevolution.org/about/transparency/"));

        LinearLayout section1View = (LinearLayout) findViewById(R.id.Section1_View);
        String d1 = "The Policy & Commitments is the section where major brands are most transparent again this year. OVS and Puma score highest in this section at 94%, among 16 other brands that score in the 90% range, 39 in the 80% range and 21 in the 70% range. This means they’re publishing all or most social and environmental policies reviewed in their own operations and suppliers, as well as disclosing how most policies are put into action and goals on human rights and environmental impacts. 26 brands score in the 0-10% range, meaning they are disclosing very few relevant policies. On a methodological note, we halved the available points in this section to shift the overall weighting towards results, outcomes and impacts.";
        String d1avg = "\n" + "\n" + "On Avarage, brands score 53% in this category.";
        section1View.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(Statistics.this).setIcon(R.drawable.info_24).setTitle("Information").setMessage(d1 + d1avg)
                        .setPositiveButton("More Information", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                startActivity(browserIntent);
                            }
                        })
                        .setNegativeButton("Close", null).show();
                ;
            }
        });

        LinearLayout section2View = (LinearLayout) findViewById(R.id.Section2_View);
        String d2 = "Balenciaga, Bottega Veneta, Gucci and Saint Laurent along with Puma, Hugo Boss and H&M score highest in this section at 85%. The majority of brands disclose contact details for the sustainability department and publish information about board accountability for human rights and environmental issues. One in 3 brands disclose incentives for executives, their employees and their suppliers to improve impacts. Very few brands disclose that workers are represented on the board of directors or publish details about their financial investments into sustainability efforts.";
        String d2avg = "\n" + "\n" + "On Avarage, brands score 31% in this category.";
        section2View.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(Statistics.this).setIcon(R.drawable.info_24).setTitle("Information").setMessage(d2 + d2avg)
                        .setPositiveButton("More Information", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                startActivity(browserIntent);
                            }
                        })
                        .setNegativeButton("Close", null).show();
                ;
            }
        });

        LinearLayout section3View = (LinearLayout) findViewById(R.id.Section3_View);
        String d3 = "More brands than ever before (47%) are disclosing their first-tier manufacturers. Four brands score above 90% in this section for the first time this year, with UGG surprisingly scoring highest this year at 97% followed by Gildan and then Zegna, OVS and Esprit respectively. This means they publish detailed factory lists at the first tier as well as some of their processing facilities and raw materials suppliers further down the chain. Notably, the majority of brands (51%) score in the 0-1% range which means they’re not disclosing any suppliers. By 2021, we had hoped to see 50% of brands publishing at least their first- tier manufacturers, so we’ll have to hold onto that hope and push for beyond 50% next year.";
        String d3avg = "\n" + "\n" + "On Avarage, brands score 19% in this category.";
        section3View.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(Statistics.this).setIcon(R.drawable.info_24).setTitle("Information").setMessage(d3 + d3avg)
                        .setPositiveButton("More Information", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                startActivity(browserIntent);
                            }
                        })
                        .setNegativeButton("Close", null).show();
                ;
            }
        });

        LinearLayout section4View = (LinearLayout) findViewById(R.id.Section4_View);
        String d4 = "This section reflects how brands assess whether their policies (those from section 1) are upheld in their supply chains and what evidence they provide that their efforts are resulting in improved working conditions and responsible environmental practices. No brand scores above 55% in this section. OVS and Target Australia score highest at 55% while 81 brands, nearly a third of all brands, score in the 0-10% range, meaning they’re disclosing nothing or very little about supply chain due diligence, supplier audits and their efforts to fix issues in factories when discovered in audits or reported by workers themselves. Whilst this is a slight improvement in comparison to last year where 100 brands scored in the 0-10% range, overall, 94% of brands are still receiving fewer than 50% of available points in this section.";
        String d4avg = "\n" + "\n" + "On Avarage, brands score 19% in this category.";
        section4View.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(Statistics.this).setIcon(R.drawable.info_24).setTitle("Information").setMessage(d4 + d4avg)
                        .setPositiveButton("More Information", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                startActivity(browserIntent);
                            }
                        })
                        .setNegativeButton("Close", null).show();
                ;
            }
        });

        LinearLayout section5View = (LinearLayout) findViewById(R.id.Section5_View);
        String d5 = "This year, OVS is the highest scoring brand in this section with 72%, up from 24% last year. Notably, OVS is the only brand scoring in the 70% range. Gucci is second highest at 66%, with H&M coming in next at 54%. Results shows that 247 brands (99%) score fewer than 50% in the Spotlight Issues section, meaning there is a widespread lack of transparency among the majority of major brands across a range of critically important and increasingly urgent issues such as Covid-19 response, purchasing practices, living wages, unionisation, gender and racial equality, use of sustainable materials, waste and circularity, water and chemicals, climate change and deforestation.";
        String d5avg = "\n" + "\n" + "On Avarage, brands score 15% in this category.";
        section5View.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(Statistics.this).setIcon(R.drawable.info_24).setTitle("Information").setMessage(d5 + d5avg)
                        .setPositiveButton("More Information", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                startActivity(browserIntent);
                            }
                        })
                        .setNegativeButton("Close", null).show();
                ;
            }
        });

        //Auswahlmöglichkeiten von verschiedenen Basisinformationen
        waschungen = (TextView) findViewById(R.id.anzahlWaschungen);


        View awView = (View) findViewById(R.id.anzahlWaschungenLayout);
        View daView = (View) findViewById(R.id.durchAuslastungLayout);
        View dtView = (View) findViewById(R.id.durchTageLayout);

        awViewVisible(awView);
        daViewInvisible(daView);
        dtViewInvisible(dtView);

        awView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                awViewVisible(awView);
                daViewInvisible(daView);
                dtViewInvisible(dtView);

            }
        });

        daView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                awViewInvisible(awView);
                daViewVisible(daView);
                dtViewInvisible(dtView);
            }
        });

        dtView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                awViewInvisible(awView);
                daViewInvisible(daView);
                dtViewVisible(dtView);
            }
        });

    }


    public void awViewVisible(View awView){
        awView.setBackgroundResource(R.drawable.scan_blue_background);
        TextView awT1 = (TextView) findViewById(R.id.anzahlWaschungenText);
        TextView awT2 = (TextView) findViewById(R.id.anzahlWaschungen);
        awT1.setTextColor(Color.WHITE);
        awT2.setTextColor(Color.WHITE);
        ImageView awIcon = (ImageView) findViewById(R.id.hashtag);
        awIcon.setColorFilter(Color.WHITE);
        TextView textView = (TextView) findViewById(R.id.infos);
        textView.setText("Hier wird dir angezeigt, wieviele Waschgänge du schon insgesamt mit der Wear-App gestartet hast. Laut Stiftung Warentest können etwa 1840 Waschgänge für eine Produktlebensdauer von 10 Jahren angenommen werden.");
        //Quelle: https://www.stern.de/digital/technik/warentest--gute-waschmaschinen-gibt-es-auch-fuer-erstaunlich-wenig-geld-7639346.html
    }

    public void awViewInvisible(View awView){
        awView.setBackgroundResource(R.drawable.scan_grey_background);
        TextView awT1 = (TextView) findViewById(R.id.anzahlWaschungenText);
        TextView awT2 = (TextView) findViewById(R.id.anzahlWaschungen);
        awT1.setTextColor(getResources().getColor(R.color.CPtextRegular));
        awT2.setTextColor(getResources().getColor(R.color.CPtextBold));
        ImageView awIcon = (ImageView) findViewById(R.id.hashtag);
        awIcon.setColorFilter(getResources().getColor(R.color.CPtextBold));
    }

    public void daViewVisible(View daView){
        daView.setBackgroundResource(R.drawable.scan_blue_background);
        TextView daT1 = (TextView) findViewById(R.id.durchAuslastungText);
        TextView daT2 = (TextView) findViewById(R.id.dAuslastung);
        daT1.setTextColor(Color.WHITE);
        daT2.setTextColor(Color.WHITE);
        ImageView daIcon = (ImageView) findViewById(R.id.hashtag1);
        daIcon.setColorFilter(Color.WHITE);
        TextView textView = (TextView) findViewById(R.id.infos);
        textView.setText("Hier wird dir angezeigt, wie hoch die durchschnittliche Auslastung deiner Waschmaschine ist, auf den gesamtem Zeitraum betrachtet. Je höher dieser Wert ist, desto effizienter sind deine Waschungen und somit ist dein Waschverhalten nachhaltiger!");
    }

    public void daViewInvisible(View daView){
        daView.setBackgroundResource(R.drawable.scan_grey_background);
        TextView daT1 = (TextView) findViewById(R.id.durchAuslastungText);
        TextView daT2 = (TextView) findViewById(R.id.dAuslastung);
        daT1.setTextColor(getResources().getColor(R.color.CPtextRegular));
        daT2.setTextColor(getResources().getColor(R.color.CPtextBold));
        ImageView daIcon = (ImageView) findViewById(R.id.hashtag1);
        daIcon.setColorFilter(getResources().getColor(R.color.CPtextBold));
    }

    public void dtViewVisible(View dtView){
        dtView.setBackgroundResource(R.drawable.scan_blue_background);
        TextView dtT1 = (TextView) findViewById(R.id.durchTageText);
        TextView dtT2 = (TextView) findViewById(R.id.dTage);
        dtT1.setTextColor(Color.WHITE);
        dtT2.setTextColor(Color.WHITE);
        ImageView dtIcon = (ImageView) findViewById(R.id.hashtag2);
        dtIcon.setColorFilter(Color.WHITE);
        TextView textView = (TextView) findViewById(R.id.infos);
        textView.setText("Hier wird dir angezeigt, wie lange du deine einzelnen Kleidungsstücke im durchschnitt besitzt. Ein Kleidungsstück gilt als nachhaltig, wenn es mindestens 30 mal getragen wurde. Dass heißt, wenn man ein Kleidungsstück 1 mal pro Woche trägt, sollte es mindestens 210 Tage in deinem Besitz sein.");
        //Quelle: https://www.harpersbazaar.de/nachhaltigkeit/shopping-tipps-nachhaltige-mode
    }

    public void dtViewInvisible(View dtView){
        dtView.setBackgroundResource(R.drawable.scan_grey_background);
        TextView dtT1 = (TextView) findViewById(R.id.durchTageText);
        TextView dtT2 = (TextView) findViewById(R.id.dTage);
        dtT1.setTextColor(getResources().getColor(R.color.CPtextRegular));
        dtT2.setTextColor(getResources().getColor(R.color.CPtextBold));
        ImageView dtIcon = (ImageView) findViewById(R.id.hashtag2);
        dtIcon.setColorFilter(getResources().getColor(R.color.CPtextBold));
    }

    //String: Parameter an doInBackground; Void: Parameter an publishProgress bzw. onProgressUpdate; String[]: Parameter von doInBackground an onPostExecute
    private class DauertLange extends AsyncTask<String, Void, String[]> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Vorher");
        }

        @Override
        protected String[] doInBackground(String... pStrings) {
            //publishProgress();
            String sN = pStrings[0];
            String tN = pStrings[1];
            String bd = pStrings[2];
            String z = pStrings[3];
            System.out.println(tN);

            String[] rueckgabe = dbConnector.select(sN, tN, bd, z);
            return rueckgabe;
        }

        protected void onPostExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Nacher");
        }
    }
}