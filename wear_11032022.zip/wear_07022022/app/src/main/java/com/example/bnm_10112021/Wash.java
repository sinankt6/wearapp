package com.example.bnm_10112021;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.anychart.core.annotations.Line;
import com.anychart.scales.Linear;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;


/**
 * Warnungs Symbol (R.drawable.warnung) von Flaticon: https://www.flaticon.com/de/autoren/gregor-cresnar (abgerufen am 30.12.2021, um 18:35)
 * exakter Downloadlink: https://www.flaticon.com/de/kostenloses-icon/mulleimer_1017530?term=m%C3%BClleimer&page=1&position=7&page=1&position=7&related_id=1017530&origin=search
 *
 * Mülleimer Symbol (R.drawable.muelleimer) von Flaticon: https://www.freepik.com (abgerufen am 30.12.2021, um 18:38)
 * exakter Downloadlink: https://www.flaticon.com/de/kostenloses-icon/warnung_159469?term=warnung&page=1&position=3&page=1&position=3&related_id=159469&origin=tag
 */

public class Wash extends AppCompatActivity {

    BottomNavigationView bottomNavigationItemView;
    DatabaseConnection dbConnector = new DatabaseConnection();


    //4-Tupel der Primärteil-Variablen
    int maxTP;
    String farbeP;
    int stoffNRP;
    String[] ausgabeP;
    String stoffArt;
    String kleidungsArtP;

    //4-Tupel der nächstes-Teil-Variablen
    int maxTN;
    String farbeN;
    int stoffNRN;
    String[] ausgabeN;
    String kleidungsArtN;

    //Variablen zur Berechnung der prozentualen Auslastung der Waschmaschine
    double gewicht = 0;
    double prozentualeAuslastung = 0;

    boolean erstesTeil = true;
    //in Minuten
    int zeitWaschgang = 0;

    String chipID;

    Context context;
    ArrayList <String> listIDs = new ArrayList<>();
    ArrayList<String> listBezeichnungen = new ArrayList<>();
    int[] listBilder = new int[40];

    TextView wFarbe;
    TextView wTemp;
    TextView wStoff;
    TextView wAuslastung;

    int anzahlTeile = 0;

    MainActivity main;

    ListView popList;
    String pieceName;
    String pieceID;
    ArrayList<String> names;
    ArrayList<String> ids;
    ArrayAdapter<String> adapter;

    int[] warnungen = new int[10];
    int wZaehler;

    //Benarichtigungen
    NotificationManagerCompat notificationManagerCompat;
    Notification notification;

    private ViewSwitcher switcher;

    //Relative Layout 2
    ImageView timerImg;
    TextView zeit;

    TextView anweisung;
    ListView popliste;
    RelativeLayout topbar2;

    //für checkAuslastung
    Boolean r = true;

    /**TextView tv1;
     TextView tv2;
     TextView tv3;
     Button jaBtn;
     Button neinBtn;**/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wash);

        //Initialisierung des Buttons zum Starten eines Waschvorgangs
        Button startButton = (Button) findViewById(R.id.startButton);
        Button startWaschgang = (Button) findViewById(R.id.startWash);


        //Relative Layout 2
        zeit = (TextView) findViewById(R.id.zeit);
        timerImg = (ImageView) findViewById(R.id.timer);
        anweisung = (TextView) findViewById(R.id.textView9);
        popliste = (ListView) findViewById(R.id.PopListe);
        topbar2 = (RelativeLayout) findViewById(R.id.topbar2);


        LinearLayout data = (LinearLayout) findViewById(R.id.data);

        wFarbe = (TextView) findViewById(R.id.wFarbe);
        wTemp = (TextView) findViewById(R.id.wTemp);
        wStoff = (TextView) findViewById(R.id.wStoff);
        wAuslastung = (TextView) findViewById(R.id.wAuslastung);

        switcher = (ViewSwitcher) findViewById(R.id.profileSwitcher);

        ListView listView = (ListView) findViewById(R.id.listView);
        popList = (ListView) findViewById(R.id.PopListe);

        main = new MainActivity();

        //ListViewAdapter adapter = new ListViewAdapter(this, listBezeichnungen, listBilder);
        CustomAdapter customAdapter = new CustomAdapter();


        bottomNavigationItemView = findViewById(R.id.navigator);
        bottomNavigationItemView.setSelectedItemId(R.id.wash);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            //Neuen Kanal für Benrachrichtigungen einrichten
            NotificationChannel channel = new NotificationChannel("myCh", "My Channel", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "myCh")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("Waschgang beendet")
                .setContentText("Der Waschgang ist fertig!");

        notification = builder.build();
        notificationManagerCompat = NotificationManagerCompat.from(this);

        //Navigationsleiste
        //DOKU, VERALTET!!!!
        bottomNavigationItemView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                switch (id) {
                    case R.id.settings:
                        startActivity(new Intent(getApplicationContext(), Settings.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.stats:
                        startActivity(new Intent(getApplicationContext(), Statistics.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.scan:
                        startActivity(new Intent(getApplicationContext(), Scan.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.wash:
                        return true;
                    case R.id.mycloset:
                        startActivity(new Intent(getApplicationContext(), MyCloset.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });

        //OnClickListener des startButtons
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switcher.showNext();
                auswahlKleidung();
            }
        });



        //Button zum Starten des Waschgangs
        startWaschgang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean w = false;
                for (int i = 0; i<warnungen.length; i++){
                    if (warnungen[i] != 0){
                        w = true;
                    }
                }
                if (prozentualeAuslastung > 100 || w){
                    new AlertDialog.Builder(Wash.this).setIcon(R.drawable.warnung).setTitle("Achtung!").setMessage("Es gibt noch offene Warnungen! Dennoch Starten?")
                            .setPositiveButton("Ja", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    startWaschgang();
                                }
                            })
                            .setNegativeButton("Nein", null).show();
                    ;
                } else {
                    startWaschgang();
                }
            }
        });

        //Neues Teil hinzufügen Button geklickt...
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == anzahlTeile) {
                    switcher.showNext();
                    auswahlKleidung();
                }

            }
        });

        //Lange auf Listelemente Drücken um sie zu Löschen
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                int position = i;
                if (position == 0){
                    Toast.makeText(getApplicationContext(), "Entfernen des Primärteils nicht möglich!", Toast.LENGTH_LONG).show();
                } else if (position == anzahlTeile) {

                } else{
                    //Pop Up Window zur Bestätigung
                    new AlertDialog.Builder(Wash.this).setIcon(R.drawable.muelleimer).setTitle("Löschen").setMessage("Wollen sie das Kleidungsstück entfernen?")
                            .setPositiveButton("Ja", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    System.out.println(position);
                                    String teilBezeichnung = listBezeichnungen.get(position);
                                    String[] rueckgabe = new String[0];
                                    try {
                                        rueckgabe = new DauertLange().execute("Art", "Kleidungstypen", "Bezeichnung = '" + teilBezeichnung + "'", "1").get();
                                    } catch (ExecutionException e) {
                                        e.printStackTrace();
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                    System.out.println(rueckgabe[0]);
                                    listBezeichnungen.remove(position);
                                    listIDs.remove(position);
                                    anzahlTeile--;
                                    gesamtesGewicht(false, rueckgabe[0]);
                                    zeigWaschinfos(farbeP, maxTP, stoffArt);
                                    //prozAuslastung checken
                                    if (prozentualeAuslastung > 100){
                                        wAuslastung.setBackgroundColor(getResources().getColor(R.color.CPwashYellowBackground));
                                    } else if (prozentualeAuslastung <= 100){
                                        wAuslastung.setBackgroundColor(getResources().getColor(R.color.CPbackground));
                                    }
                                    //Warnungen anpassen
                                    for (int z = 0; z < warnungen.length; z++) {
                                        if (warnungen[z] == position) {
                                            warnungen[z] = 0;
                                        }
                                        if (warnungen[z] > position) {
                                            warnungen[z]--;
                                        }
                                    }

                                    customAdapter.notifyDataSetChanged();
                                }
                            })
                            .setNegativeButton("Nein", null).show();
                    return true;
                }
                return true;
            }
        });
        popList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                pieceName = names.get(i);
                pieceID = ids.get(i);
                startWaschgang.setVisibility(View.VISIBLE);
                switcher.showPrevious();
                if(erstesTeil){
                    //Abfrage der zum Waschen relevanten Daten
                    String[] ausgabeP = new String[5];
                    try {
                        ausgabeP = new DauertLange().execute("Art, Stoffnummer, Farbe, maxTemperatur, Bezeichnung", "Kleidungstypen", "Seriennummer = '" + pieceID + "'", "5").get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    System.out.println(ausgabeP[1]);
                    kleidungsArtP = ausgabeP[0];
                    stoffNRP = Integer.parseInt(ausgabeP[1]);
                    farbeP = ausgabeP[2];
                    maxTP = Integer.parseInt(ausgabeP[3]);
                    listBezeichnungen.add(ausgabeP[4]);
                    listIDs.add(pieceID);
                    anzahlTeile++;

                    listBezeichnungen.add("Weiteres Teil Hinzufügen");

                    auswahlFarbe(farbeP);
                    auswahlWaschgang(stoffNRP);
                    gesamtesGewicht(true, kleidungsArtP);

                    //Primärteil in Liste anzeigen
                    zeigWaschinfos(farbeP, maxTP, stoffArt);
                    listView.setAdapter(customAdapter);
                    erstesTeil = false;
                    startButton.setVisibility(View.INVISIBLE);
                    data.setVisibility(View.VISIBLE);
                } else {
                    //Abfrage der zum Waschen relevanten Daten
                    try {
                        ausgabeN = new DauertLange().execute("Art, Stoffnummer, Farbe, maxTemperatur, Bezeichnung", "Kleidungstypen", "Seriennummer = '" + pieceID + "'", "5").get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    kleidungsArtN = ausgabeN[0];
                    stoffNRN = Integer.parseInt(ausgabeN[1]);
                    farbeN = ausgabeN[2];
                    maxTN = Integer.parseInt(ausgabeN[3]);
                    //Überprüfung, ob kompatibel
                    auswahlFarbe(farbeN);
                    if (naechstesTeil()) {
                        if (checkAuslastung(prozentualeAuslastung)) {
                            listBezeichnungen.remove(anzahlTeile);
                            listBezeichnungen.add(ausgabeN[4]);
                            listIDs.add(pieceID);
                            listBezeichnungen.add("Weiteres Teil Hinzufügen");
                            anzahlTeile++;
                            startWaschgang.setVisibility(View.VISIBLE);
                            customAdapter.notifyDataSetChanged();
                            wAuslastung.setText("Auslastung: " + prozentualeAuslastung + "%");
                        }

                    } else{
                        //Pop Up Window: Warnung
                        new AlertDialog.Builder(Wash.this).setIcon(R.drawable.warnung).setTitle("Achtung!").setMessage("Wir empfehlen Ihnen das Kleidungsstück nicht mit den anderen zusammen zu waschen! Wollen sie das Kleidungsstück dennoch mit waschen?")
                                .setPositiveButton("Ja", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        listBezeichnungen.remove(anzahlTeile);
                                        listBezeichnungen.add(ausgabeN[4]);
                                        listIDs.add(pieceID);
                                        listBezeichnungen.add("Weiteres Teil Hinzufügen");
                                        warnungen[wZaehler] = anzahlTeile;
                                        anzahlTeile++;
                                        wZaehler ++;
                                        customAdapter.notifyDataSetChanged();
                                        gesamtesGewicht(true, kleidungsArtN);
                                        wAuslastung.setText(prozentualeAuslastung + "%");
                                        //prozAuslastung checken
                                        if (prozentualeAuslastung > 100){
                                            wAuslastung.setBackgroundColor(getResources().getColor(R.color.CPwashYellowBackground));
                                        } else if (prozentualeAuslastung <= 100){
                                            wAuslastung.setBackgroundColor(getResources().getColor(R.color.CPbackground));
                                        }
                                        startWaschgang.setVisibility(View.VISIBLE);
                                        switcher.showPrevious();

                                    }
                                })
                                .setNegativeButton("Nein", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        startWaschgang.setVisibility(View.VISIBLE);
                                        switcher.showPrevious();
                                    }
                                }).show();
                        ;
                    }
                }
            }
        });
    }

    public void startWaschgang(){
        for (int p = 0; p<anzahlTeile ; p++){
            //Haeufigkeit des Waschens des Kleidungsstücks  wird in der Datenbank um einen erhöht
            String[] rueckgabe = new String[1];
            try {
                rueckgabe = new DauertLange().execute("Waschhaeufigkeit", "Chips", "Seriennummer = '" + listIDs.get(p) + "'", "1").get();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            int nWasch = Integer.valueOf(rueckgabe[0])+1;
            dbConnector.update("Waschhaeufigkeit", "Seriennummer", "Chips", "'" + listIDs.get(p) + "'",  String.valueOf(nWasch));
        }


        //durchschnittliche Auslastung der Waschmaschinen des Benutzers in der DB aktualisieren
        String[] aAuslastung = new String[1];
        try {
            aAuslastung = new DauertLange().execute("dAuslastung", "Benutzerdaten", "BenutzerID = '" + UserInformation.get().getUserID() + "'", "1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int nDurchschnitt = (int) (prozentualeAuslastung + Integer.valueOf(aAuslastung[0])) / 2;
        dbConnector.update("dAuslastung", "BenutzerID", "Benutzerdaten", "'" + UserInformation.get().getUserID() + "'", "'" + nDurchschnitt + "'");

        //Waschmaschine inkl. Daten werden mit Datum in DB eingefügt
        Date d = Calendar.getInstance().getTime();
        SimpleDateFormat dateformat = new SimpleDateFormat("dd/MM/yyyy");
        String datum = dateformat.format(d);
        dbConnector.insert("Entwicklung", "BenutzerID, Datum, Auslastung", "('" + UserInformation.get().getUserID() + "', '" + datum + "', '" + (int) prozentualeAuslastung + "')");

        timerImg.setVisibility(View.VISIBLE);
        zeit.setVisibility(View.VISIBLE);
        anweisung.setVisibility(View.INVISIBLE);
        popliste.setVisibility(View.INVISIBLE);
        switcher.showNext();



        //Format der Zahlen vorgeben
        DecimalFormat df = new DecimalFormat("00");

        //Timer für die Waschmaschine
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            int zeitSek = zeitWaschgang * 60;


            // @Override
            public void run() {
                Wash.this.runOnUiThread(new Runnable(){
                    @Override
                    public void run() {
                        zeitSek--;

                        zeit.setText("Verbleibende Zeit: " + df.format(zeitSek / 60) + ":" + df.format(zeitSek % 60));

                        //Wenn Timer abgelaufen
                        if (zeitSek == 0) {
                            timer.cancel();
                            notificationManagerCompat.notify(1, notification);
                        }
                    }
                });
            }
        }, 1000, 1000);
    }

    //Kategorisieren der Farbe
    public void auswahlFarbe(String farbe) {
        if (erstesTeil) {
            System.out.println(farbe);
            if (farbe.equals("Blau") || farbe.equals("Schwarz") || farbe.equals("Dunkelgrau")) {
                farbeP = "dunkel";
            } else if (farbe.equals("weiss")) {
                farbeP = "weiss";
            } else {
                farbeP = "bunt";
            }
        } else {
            if (farbe.equals("Blau") || farbe.equals("Schwarz") || farbe.equals("Dunkelgrau")) {
                farbeN = "dunkel";
            } else if (farbe.equals("weiss")) {
                farbeN = "weiss";
            } else {
                farbeN = "bunt";
            }
        }
    }

    // Überprüfung der weiteren Teile mit der entsprechenden Ausgabe je nachdem ob das Hinzugefügte Kleidungsstück mit dem Primärteil kompatibel ist
    public boolean naechstesTeil() {
        if (maxTP >= maxTN && stoffNRP == stoffNRN && farbeP.equals(farbeN)) {
            //Hinzufügen zum ListView des neuen Teils
            Toast.makeText(getApplicationContext(), "Teil wurde erfolgreich hinzugefügt!", Toast.LENGTH_LONG).show();
            gesamtesGewicht(true, kleidungsArtN);
            return true;
        } else {
            //Pop Up Fehlermeldung aber Option zum trotzdem Hinzufügen
            Toast.makeText(getApplicationContext(), "Achtung: Der Hersteller empfiehlt dieses Teil nicht mit den anderen zusammen zu waschen.", Toast.LENGTH_LONG).show();
            switcher.showNext();
            return false;
        }
    }

    //passender Waschgang wird nach Werten des Primärteils ausgewählt
    public void auswahlWaschgang(int stoffNr) {
        if (farbeP.equals("dunkel")) {
            auswahlTextilart(stoffNr);
        } else if (farbeP.equals("weiss")) {
            auswahlTextilart(stoffNr);
        } else if (farbeP.equals("bunt")) {
            auswahlTextilart(stoffNr);
        }
        return;
    }

    //Hinzufügen des Gewichts from Primärteil zum Gesamtgewicht
    public void gesamtesGewicht(Boolean plus, String kleidungsArt) {
        System.out.println(kleidungsArt);
        /**
         * Quellen für Gewichte von Kleidungsstücken:
         * https://www.personenwaage-online.de/wie-viel-wiegt/wiegen-mit-kleidung-was-wiegen-klamotten/ (zuletzt abgerufen am 07.02.2022)
         * https://telebasel.ch/2019/10/30/ein-kilo-kleider-bitte/?channel=105100 (zuletzt abgerufen am 07.02.2022)
         */
        if (plus) {
            if (kleidungsArt.equals("T-Shirts")) {
                gewicht = gewicht + 0.2;
            } else if (kleidungsArt.equals("Kapuzenpullover")) {
                gewicht = gewicht + 1;
            } else if (kleidungsArt.equals("Jacken")) {
                gewicht = gewicht + 0.9;
            } else if (kleidungsArt.equals("Jeans")) {
                gewicht = gewicht + 0.7;
            } else if (kleidungsArt.equals("Kleider")) {
                gewicht = gewicht + 0.2;
            }
        } else{
            if (kleidungsArt.equals("T-Shirts")) {
                gewicht = gewicht - 0.2;
            } else if (kleidungsArt.equals("Kapuzenpullover")) {
                gewicht = gewicht - 1;
            } else if (kleidungsArt.equals("Jacken")) {
                gewicht = gewicht - 0.9;
            } else if (kleidungsArt.equals("Jeansttim")) {
                gewicht = gewicht - 0.7;
            } else if (kleidungsArt.equals("Kleider")) {
                gewicht = gewicht - 0.2;
            }
        }
        prozentualeAuslastung = (gewicht / 6) * 100;
        prozentualeAuslastung = Math.round(prozentualeAuslastung);

        System.out.println("Die Waschmaschine ist zu " + prozentualeAuslastung + " % ausgelastet!");
    }

    public Boolean checkAuslastung(double prozAuslastung){
        if (prozAuslastung > 100){
            new AlertDialog.Builder(Wash.this).setIcon(R.drawable.warnung).setTitle("Achtung!").setMessage("Das Maximalgewicht der Waschmaschine ist überschritten. Dennoch hinzufügen?")
                    .setPositiveButton("Ja", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            r = true;
                            wAuslastung.setBackgroundColor(Color.YELLOW);
                        }
                    })
                    .setNegativeButton("Nein", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            r = false;
                        }
                    }).show();
            ;
        } else{
            r = true;
        }
        return r;
    }

    public String auswahlTextilart(int stoffNR) {
        if (stoffNR == 3) {
            System.out.println("Waschgang: Seide bei 30 Grad");
            stoffArt = "Seide";
            zeitWaschgang = 38;
        } else if (stoffNR == 1) {
            System.out.println("Waschgang: Wolle/Handwäsche bei" + maxTP + "Grad");
            stoffArt = "Wolle";
            zeitWaschgang = 39;
        } else if (stoffNR == 0) {
            System.out.println("Waschgang: Baumwolle bei maximal" + maxTP + "Grad");
            stoffArt = "Baumwolle";
            zeitWaschgang = 90; //Überprüfen!!
        } else if (stoffNR == 4) {
            System.out.println("Waschgang: Synthetic bei maximal" + maxTP + "Grad");
            stoffArt = "Pflegeleicht";
            zeitWaschgang = 59;
        } else if (stoffNR == 2) {
            stoffArt = "Jeans";
            zeitWaschgang = 1;
        } else if (stoffNR == 5) {
            stoffArt = "Outdoor";
            zeitWaschgang = 59;
        } else if (stoffNR == 6) {
            stoffArt = "Synthetic";
            zeitWaschgang = 59;
        }
        return stoffArt;
    }

    public void zeigWaschinfos(String farbe, int temperatur, String stoff) {
        wFarbe.setText(farbe.toUpperCase(Locale.ROOT));
        wStoff.setText(stoff.toUpperCase(Locale.ROOT));
        wTemp.setText(temperatur + "°");
        wAuslastung.setText(prozentualeAuslastung + "%");

        wFarbe.setVisibility(View.VISIBLE);
        wStoff.setVisibility(View.VISIBLE);
        wTemp.setVisibility(View.VISIBLE);
        wAuslastung.setVisibility(View.VISIBLE);

    }

    public void auswahlKleidung() {

        String[] werte = new String[0];
        try {
            werte = new DauertLange().execute("Kleidungstypen.Bezeichnung, Kleidungstypen.Seriennummer", "Kleidungstypen INNER JOIN Chips ON Kleidungstypen.Seriennummer = Chips.Seriennummer", "BenutzerID = '" + UserInformation.get().getUserID() + "'", "2").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        popList = (ListView) findViewById(R.id.PopListe);
        names = new ArrayList<>();
        ids = new ArrayList<>();

        for (int i = 0; i < werte.length; i++) {
            System.out.println("i " + i);
            if (i % 2 == 0) {
                names.add(werte[i]);
            } else {
                ids.add(String.valueOf(werte[i]));

            }
        }

        adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, names);
        popList.setAdapter(adapter);

    }

    //ASyncTask zur Datenbank Verbindung, sodass im main-thread was anderes weiter laufen kann
    private class DauertLange extends AsyncTask<String, Void, String[]> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Vorher");
        }

        @Override
        protected String[] doInBackground(String... pStrings) {
            //publishProgress();
            String sN = pStrings[0];
            String tN = pStrings[1];
            String bd = pStrings[2];
            String z = pStrings[3];
            String[] ausgabe = dbConnector.select(sN, tN, bd, z);
            return ausgabe;
        }

        protected void onPostExecute() {
            super.onPreExecute();
            //Loading Animation
            System.out.println("Nacher");
        }
    }

    //Adapter für das ListView
    private class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return anzahlTeile + 1;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        //Darstellung wird erstellt und Textfeld und Bild mit Daten gefüllt
        public View getView(int i, View view, ViewGroup viewGroup) {
            View listElement = getLayoutInflater().inflate(R.layout.list_element, null);
            ImageView images = listElement.findViewById(R.id.bild);
            TextView bezeichnung = listElement.findViewById(R.id.bezeichnung);
            listElement.setBackgroundResource(R.drawable.wash_noselection);

            if (i == 0) {
                //listElement.setBackgroundColor(Color.GREEN);
                listElement.setBackgroundResource(R.drawable.wash_selection_green);
            } else {
                for (int k = 0; k < warnungen.length; k++) {
                    if (warnungen[k] == i) {
                        listElement.setBackgroundResource(R.drawable.wash_selection_yellow);
                    }
                }
            }
            //images.setImageResource(listBilder[position]);
            if(i != anzahlTeile) {
                images.setImageResource(R.drawable.tshirt);
            }
            bezeichnung.setText(listBezeichnungen.get(i));

            return listElement;
        }
    }
}
